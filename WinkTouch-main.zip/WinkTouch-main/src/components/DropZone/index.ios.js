import React, {Component} from 'react';
import {Text, View} from 'react-native';

export default class UploadZone extends Component {
  render() {
    return (
      <View>
        <Text> Not enabled for mobile </Text>
      </View>
    );
  }
}

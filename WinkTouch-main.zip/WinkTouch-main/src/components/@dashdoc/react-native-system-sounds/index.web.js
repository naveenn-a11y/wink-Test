class RNSystemSounds {
  // some fancy code here
  static beep(success) {
    console.log('RNBeep not handled for web');
  }

  static play(soundID) {
    console.log('RNBeep PlaySound not handled for web');
  }
  static AndroidSoundIDs = {};
  static iOSSoundIDs = {};
  static Beeps = {}
}
export default RNSystemSounds;

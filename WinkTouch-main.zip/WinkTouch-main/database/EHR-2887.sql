DELETE FROM `6421_5tmkd`.`lists` WHERE (`description_en` = 'Urticaria' AND `idlists` = '82587');
DELETE FROM `6421_5tmkd`.`lists` WHERE (`description_en` = 'Reactine' AND `idlists` = '83493');
DELETE FROM `6421_5tmkd`.`lists` WHERE (`description_en` = 'Symbicort' AND `idlists` = '83524');
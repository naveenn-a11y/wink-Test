INSERT INTO 5694_6gjpk.lists (list_name, description_en, description_fr, rank_en, rank_fr, rank_it, rank_es)
VALUES ('corneaCodes.1', 'Arcus', 'Arc', '0', '0', '0', '0');

INSERT INTO 5694_6gjpk.lists (list_name, description_en, description_fr, rank_en, rank_fr, rank_it, rank_es)
VALUES ('corneaCodes.1', 'Flap Scars', 'Cicatrice de volet', '0', '0', '0', '0');

INSERT INTO 5694_6gjpk.lists (list_name, description_en, description_fr, rank_en, rank_fr, rank_it, rank_es)
VALUES ('corneaCodes.1', 'Pigment Dispersion', 'Dispersion de pigment', '0', '0', '0', '0');

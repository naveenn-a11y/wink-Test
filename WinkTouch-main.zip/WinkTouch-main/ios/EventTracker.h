//
//  EventTracker.h
//  WinkTouch
//
//  Created by Femi Oluwaniran on 09/05/2022.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "RCTEventTrackerModule.h"

@interface EventTracker : UIApplication


@end
#import <UIKit/UIKit.h>

#import "AppDelegate.h"
#import "EventTracker.h"

int main(int argc, char *argv[])
{
  @autoreleasepool {
    return UIApplicationMain(argc, argv, @"EventTracker", NSStringFromClass([AppDelegate class]));
  }
}

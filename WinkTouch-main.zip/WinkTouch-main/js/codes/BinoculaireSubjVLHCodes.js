/**
 * @flow
 */
'use strict';

export const binoculaireSubjVLHCodes = [
{"code":"Eso"},
{"code":"Exo"},
]

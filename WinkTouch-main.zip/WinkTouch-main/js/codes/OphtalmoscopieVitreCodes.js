/**
 * @flow
 */
'use strict';

export const ophtalmoscopieVitreCodes = [
{"code":"Clair"},
{"code":"Flottant"},
]

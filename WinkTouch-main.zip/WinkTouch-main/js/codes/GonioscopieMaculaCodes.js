/**
 * @flow
 */
'use strict';

export const gonioscopieMaculaCodes = [
]

/**
 * @flow
 */
'use strict';

export const deviationVCodes = [
{"code":"Hyper"},
{"code":"Hypo"},
]

/**
 * @flow
 */
'use strict';

export const biomicroscopieChAntCodes = [
{"code":"Cell. Inflam."},
{"code":"Claire"},
{"code":"Flare"},
{"code":"Hyphéma"},
{"code":"Hypopion"},
{"code":"Normale"},
]

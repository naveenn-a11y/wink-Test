/**
 * @flow
 */
'use strict';

export const complaintContextCodes = [
{"code":"Driving"},
{"code":"Working on computer"},
{"code":"Watching tv"},
{"code":"Reading schoolboard"},
{"code":"Reading"},
{"code":"Wearing contacts"},
{"code":"Wearing glasses"},
{"code":"Looking to the left"},
{"code":"Looking to the right"},
{"code":"Looking up"},
{"code":"Looking down"},
]

/**
 * @flow
 */
'use strict';

export const binoculaireSubjVLVCodes = [
{"code":"Hyper"},
{"code":"Hypo"},
]

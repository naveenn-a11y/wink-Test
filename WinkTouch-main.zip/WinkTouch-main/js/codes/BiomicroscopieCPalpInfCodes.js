/**
 * @flow
 */
'use strict';

export const biomicroscopieCPalpInfCodes = [
{"code":"CPG 1"},
{"code":"CPG 2"},
{"code":"CPG 3"},
{"code":"CPG 4"},
{"code":"Folicule"},
{"code":"K. rétention"},
{"code":"Lithiase"},
{"code":"Normale"},
]

/**
 * @flow
 */
'use strict';

export const santePosologie2Codes = [
{"code":"Normal"},
]

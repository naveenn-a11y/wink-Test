/**
 * @flow
 */
'use strict';

export const biomicroscopieCBulbCodes = [
{"code":"Hypérémie"},
{"code":"Normale"},
{"code":"Pigmentation"},
{"code":"Pinguécula"},
{"code":"Ptérygion"},
{"code":"Sécrétion"},
{"code":"Œdème"},
]

/**
 * @flow
 */
'use strict';

export const vision3Codes = [
{"code":"Alt.(+ souvent OD)"},
{"code":"Alt.(+ souvent OG)"},
{"code":"Alternante"},
{"code":"Constante OD"},
{"code":"Constante OG"},
]

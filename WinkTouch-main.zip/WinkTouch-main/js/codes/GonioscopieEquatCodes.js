/**
 * @flow
 */
'use strict';

export const gonioscopieEquatCodes = [
]

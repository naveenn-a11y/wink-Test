/**
 * @flow
 */
'use strict';

export const resumeResultatCodes = [
{"code":"Commander nouvelles LC"},
{"code":"Problème résolu"},
]

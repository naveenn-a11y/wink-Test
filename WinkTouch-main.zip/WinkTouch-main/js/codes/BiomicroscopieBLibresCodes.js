/**
 * @flow
 */
'use strict';

export const biomicroscopieBLibresCodes = [
{"code":"Blépharite"},
{"code":"Chalazion"},
{"code":"Cong. G. M."},
{"code":"Ectropion"},
{"code":"Entropion"},
{"code":"Normaux"},
{"code":"Orgelet"},
]

/**
 * @flow
 */
'use strict';

export const santePosologie1Codes = [
{"code":"Normal"},
]

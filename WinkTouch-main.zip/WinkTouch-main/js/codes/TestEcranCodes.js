/**
 * @flow
 */
'use strict';

export const testEcranCodes = [
{"code":"Unilateral"},
{"code":"Alternated"},
]

/**
 * @flow
 */
'use strict';

export const resumeVerificationCodes = [
{"code":"Amélioration de la rougeur"},
{"code":"Amélioration du larmoiement"},
{"code":"Confort avec nouvelles LC"},
]

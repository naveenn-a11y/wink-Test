/**
 * @flow
 */
'use strict';

export const vision2Codes = [
{"code":"Compensée"},
{"code":"Constante"},
{"code":"Décompensée"},
{"code":"Intermitante"},
]

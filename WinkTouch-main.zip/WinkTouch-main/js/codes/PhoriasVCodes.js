/**
 * @flow
 */
 'use strict';

 export const phoriasVCodes = [
   {code: ' R Hyperphoria'},
   {code: ' L Hyperphoria'},
 ];
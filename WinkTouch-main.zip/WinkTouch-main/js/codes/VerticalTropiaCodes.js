/**
 * @flow
 */
'use strict';

export const verticalTropiaCodes = [
  {code: ' Hypertropia'},
  {code: ' Hypotropia'},
];

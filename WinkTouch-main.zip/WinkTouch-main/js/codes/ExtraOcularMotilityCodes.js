/**
 * @flow
 */
'use strict';

export const extraOcularMotilityCodes = [
{"code":"Smooth and full"},
{"code":"Diplopia"},
{"code":"Restriction"},
{"code":"Lags behind"},
{"code":"Overshoots"}
]

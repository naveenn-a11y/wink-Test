/**
 * @flow
 */
'use strict';

export const dominanceCodes = [
{"code":"Right"},
{"code":"Left"},
]

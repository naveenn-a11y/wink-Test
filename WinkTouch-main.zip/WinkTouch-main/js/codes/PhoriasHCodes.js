/**
 * @flow
 */
 'use strict';

 export const phoriasHCodes = [
    {code: ' Esophoria'},
    {code: ' Exophoria'},
 ];

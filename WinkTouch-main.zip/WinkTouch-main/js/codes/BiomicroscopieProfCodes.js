/**
 * @flow
 */
'use strict';

export const biomicroscopieProfCodes = [
{"code":"1 / 1"},
{"code":"1 / 2"},
{"code":"1 / 3"},
{"code":"1 / 4"},
{"code":"1 / 5"},
]

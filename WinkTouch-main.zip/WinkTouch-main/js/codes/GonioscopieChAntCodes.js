/**
 * @flow
 */
'use strict';

export const gonioscopieChAntCodes = [
{"code":"0"},
{"code":"1"},
{"code":"2"},
{"code":"3"},
{"code":"4"},
]

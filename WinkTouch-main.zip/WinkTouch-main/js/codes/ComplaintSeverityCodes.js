/**
 * @flow
 */
'use strict';

export const complaintSeverityCodes = [
{"code":"Mild"},
{"code":"Moderate"},
{"code":"Severe"},
]

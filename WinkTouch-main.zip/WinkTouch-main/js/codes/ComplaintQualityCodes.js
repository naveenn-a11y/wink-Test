/**
 * @flow
 */
'use strict';

export const complaintQualityCodes = [
{"code":"Sharp"},
{"code":"Dull"},
{"code":"Throbbing"},
{"code":"Radiating"},
{"code":"Localized"},
{"code":"Constant"},
{"code":"Intermittent"},
{"code":"Chronic"},
{"code":"Stable"},
{"code":"Improving"},
{"code":"Worsening"},
]

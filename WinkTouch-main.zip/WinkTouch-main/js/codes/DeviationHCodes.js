/**
 * @flow
 */
'use strict';

export const deviationHCodes = [
{"code":"Eso"},
{"code":"Exo"},
]

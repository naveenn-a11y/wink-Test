/**
 * @flow
 */
'use strict';

export const Codes = [
{"code":""},
{"code":""},
{"code":""},
{"code":""},
{"code":""},
{"code":""},
{"code":""},
{"code":""},
{"code":""},
{"code":""},
{"code":""},
{"code":""},
{"code":""},
{"code":""},
{"code":""},
{"code":""},
{"code":""},
{"code":""},
{"code":""},
{"code":""},
{"code":""},
{"code":""},
{"code":""},
{"code":""},
{"code":""},
]

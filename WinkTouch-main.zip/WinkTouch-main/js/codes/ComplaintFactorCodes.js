/**
 * @flow
 */
'use strict';

export const complaintFactorCodes = [
{"code":"Medication"},
{"code":"Sleep"},
{"code":"Cool compress"},
{"code":"Warm compress"},
{"code":"Low light"},
]

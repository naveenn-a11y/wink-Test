/**
 * @flow
 */
'use strict';

export const gonioscopiePapilleCodes = [
]

/**
 * @flow
 */
'use strict';

export const biomicroscopieCristCodes = [
{"code":"Cat. Capsulaire"},
{"code":"Cat. Corticale"},
{"code":"Cat. Nucléaire"},
{"code":"Cat. Sous-caps. Post."},
{"code":"Claire"},
{"code":"Normale"},
{"code":"Pigmentation"},
{"code":"Pseudophakie"},
]

/**
 * @flow
 */
'use strict';

export const resumeTestCodes = [
{"code":"BIO"},
{"code":"Biomicroscopie"},
{"code":"Champ central"},
{"code":"Champ périphérique"},
{"code":"Cycloplégie"},
{"code":"Dilatatio"},
{"code":"Ecran tangent normal O.U."},
{"code":"Gonioscopie"},
{"code":"Grille D'Amsler"},
{"code":"Humphrey FDT N O.U."},
{"code":"Humphrey FDT anormal"},
{"code":"Photos de fond d'œil"},
{"code":"Photos pour Labo RD"},
{"code":"Tonometrie"},
{"code":"Volk"},
]

/**
 * @flow
 */
'use strict';

export const biomicroscopieSclerCodes = [
{"code":"Normale"},
{"code":"Sclérite"},
{"code":"Épisclérite"},
]

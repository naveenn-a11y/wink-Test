/**
 * @flow
 */
'use strict';

export const ophtalmoscopieMaculaCodes = [
{"code":"DMLA"},
{"code":"RF + Rond flou"},
{"code":"RF + Rond précis"},
{"code":"RF -"},
{"code":"RF - Saine"},
{"code":"Saine"},
]

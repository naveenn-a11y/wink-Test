/**
 * @flow
 */
'use strict';

export const eyeColorCodes = [
{"code":"Brown"},
{"code":"Hazel"},
{"code":"Gray"},
{"code":"Blue"},
{"code":"Amber"},
{"code":"Violet/Red"},
{"code":"Green"},
{"code":"Heterochromia"}
]

/**
 * @flow
 */
'use strict';

export const vaScaleCodes = [
{"code":"Snellen"},
{"code":"Numbers"},
{"code":"Tumbling E"},
{"code":"HOTV"},
{"code":"Allen Pictures"}
]

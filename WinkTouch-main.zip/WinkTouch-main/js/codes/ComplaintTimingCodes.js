/**
 * @flow
 */
'use strict';

export const complaintTimingCodes = [
{"code":"Recurrent"},
{"code":"Continious"},
{"code":"Comes and goes"},
{"code":"Seldom"},
{"code":"Frequently"},
{"code":"Varies in time"},
{"code":"Sudden"},
{"code":"Slowly"},
]

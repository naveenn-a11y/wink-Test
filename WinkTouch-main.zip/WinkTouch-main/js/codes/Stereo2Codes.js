/**
 * @flow
 */
'use strict';

export const stereo2Codes = [
{"code":"A"},
{"code":"B"},
{"code":"C"},
]

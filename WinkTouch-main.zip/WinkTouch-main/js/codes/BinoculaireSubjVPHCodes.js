/**
 * @flow
 */
'use strict';

export const binoculaireSubjVPHCodes = [
{"code":"Eso"},
{"code":"Exo"},
]

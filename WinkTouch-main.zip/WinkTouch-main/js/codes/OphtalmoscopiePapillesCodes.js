/**
 * @flow
 */
'use strict';

export const ophtalmoscopiePapillesCodes = [
{"code":"Croissant chor."},
{"code":"D + R"},
{"code":"PPA"},
{"code":"Pâleur"},
{"code":"Saine"},
{"code":"Tilted"},
{"code":"Type 1"},
{"code":"Type 2"},
{"code":"Type 3"},
{"code":"Type 4"},
]

/**
 * @flow
 */
'use strict';

export const lateralPhoriaCodes = [
  {code: ' Esophoria'},
  {code: ' Exophoria'},
  {code: ' Alternating Esophoria'},
  {code: ' Alternating Exophoria'},
  {code: ' Intermittent Alternating'},
];

/**
 * @flow
 */
'use strict';

export const vision1Codes = [
{"code":"Esophorie"},
{"code":"Esotropie"},
{"code":"Exophorie"},
{"code":"Exotropie"},
{"code":"Hyperphorie"},
{"code":"Hypertropie"},
{"code":"Hypophorie"},
{"code":"Hypotropie"},
{"code":"Ortho"},
]

/**
 * @flow
 */
'use strict';

export const biomicroscopieCorneeCodes = [
{"code":"Fluo +"},
{"code":"Infiltrats"},
{"code":"Normale"},
{"code":"Néovasc."},
{"code":"Opacités"},
{"code":"Œdème"},
]

/**
 * @flow
 */
'use strict';

export const lensTypeCodes = [
{"code":"Single Vision"},
{"code":"Anti-Fatigue"},
{"code":"Progressive"},
{"code":"Bifocal"},
{"code":"Sunglasses"},
{"code":"Computer"}
]

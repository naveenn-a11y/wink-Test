/**
 * @flow
 */
'use strict';

export const biomicroscopieIrisCodes = [
{"code":"Cc"},
{"code":"Cx"},
{"code":"Iridotomie"},
{"code":"Plat"},
]

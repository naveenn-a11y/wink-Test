/**
 * @flow
 */
'use strict';

export const lateralTropiaCodes = [{code: ' Esotropia'}, {code: ' Exotropia'}];

/**
 * @flow
 */
'use strict';

export const filtreRougeCodes = [
{"code":"Eso"},
{"code":"Exo"},
{"code":"Hyper OD"},
{"code":"Hypo OD"},
{"code":"Orho"},
{"code":"Suppression"},
]

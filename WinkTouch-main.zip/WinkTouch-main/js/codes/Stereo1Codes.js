/**
 * @flow
 */
'use strict';

export const stereo1Codes = [
{"code":"No"},
{"code":"Yes"},
]

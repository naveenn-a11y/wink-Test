/**
 * @flow
 */
'use strict';

export const binoculaireSubjVPVCodes = [
{"code":"Hyper"},
{"code":"Hypo"},
]

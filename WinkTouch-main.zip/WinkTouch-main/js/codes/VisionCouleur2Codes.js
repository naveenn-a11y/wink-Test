/**
 * @flow
 */
'use strict';

export const visionCouleur2Codes = [
{"code":"Deutéranomalie (vert)"},
{"code":"Deutéranopie"},
{"code":"N/C"},
{"code":"Normale"},
{"code":"Pronatopie"},
{"code":"Protéranomalie (rouge)"},
{"code":"Trinatopie"},
{"code":"Tritanomalie (bleu)"},
]

/**
 * @flow
 */
'use strict';

export const biomicroscopieLimbeCodes = [
{"code":"Normale"},
{"code":"Vasc. Complète"},
{"code":"Vasc. Localisée"},
]

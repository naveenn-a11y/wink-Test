/**
 * @flow
 */
'use strict';

export const vision4Codes = [
{"code":"Cocommitant"},
{"code":"Incommitant"},
]

/**
 * @flow
 */
'use strict';

export const complaintSignCodes = [
{"code":"Anxiety"},
{"code":"Balance problems"},
{"code":"Black spots"},
{"code":"Bleeding"},
{"code":"Blind spot"},
{"code":"Bump on lower lid margin"},
{"code":"Bump on upper lid margin"},
]

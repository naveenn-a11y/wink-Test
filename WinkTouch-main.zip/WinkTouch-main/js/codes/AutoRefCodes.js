/**
 * @flow
 */
'use strict';

export const currentWearCodes = [
    {"code":"Glasses"},
    {"code":"No glasses"},
    {"code":"Did not bring glasses"},
    {"code":"Lost glasses"}
]

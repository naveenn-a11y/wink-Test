/**
 * @flow
 */
'use strict';

export const verticalPhoriaCodes = [
  {code: ' Hyperphoria'},
  {code: ' Hypophoria'},
  {code: ' Alternating Hyperphoria'},
  {code: ' Alternating Hypophoria'},
  {code: ' Intermittent Alternating'},
];

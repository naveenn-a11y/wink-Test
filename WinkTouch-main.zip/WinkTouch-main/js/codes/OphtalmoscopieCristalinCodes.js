/**
 * @flow
 */
'use strict';

export const ophtalmoscopieCristalinCodes = [
{"code":"Cataracte"},
{"code":"Clair"},
{"code":"Opacité I."},
{"code":"Opacité M."},
{"code":"Opacité P."},
]

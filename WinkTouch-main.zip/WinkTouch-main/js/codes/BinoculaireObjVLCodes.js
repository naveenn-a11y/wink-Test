/**
 * @flow
 */
'use strict';

export const binoculaireObjVLCodes = [
{"code":"Auto-réfracto"},
{"code":"Rétino I.M."},
{"code":"Rétino statique"},
]

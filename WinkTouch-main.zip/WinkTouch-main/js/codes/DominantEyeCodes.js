/**
 * @flow
 */
'use strict';

export const dominantEyeCodes = [
{"code":"OD"},
{"code":"OS"},
{"code":"OU"}
]

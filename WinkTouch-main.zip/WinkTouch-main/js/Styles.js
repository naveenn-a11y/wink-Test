import {
  Dimensions,
  PixelRatio,
  Platform,
  StyleSheet,
  UIManager,
} from 'react-native';

export const windowWidth: number =
  Dimensions.get('window').width < Dimensions.get('window').height
    ? Dimensions.get('window').height
    : Dimensions.get('window').width;
export const windowHeight: number =
  Dimensions.get('window').height < Dimensions.get('window').width
    ? Dimensions.get('window').height
    : Dimensions.get('window').width;

export const fontScale =
  0.75 * Math.min(1, Math.min(windowWidth / 1024, windowHeight / 768));
export const globalFontScale = 0.75 * Math.min(1, Math.min(windowWidth / 1024, windowHeight / 768));
__DEV__ &&
  console.log(
    'Device resolution: ' +
      windowWidth +
      'x' +
      windowHeight +
      ' -> scale=' +
      fontScale,
  );

export const widthPercentageToDP = (widthPercent) => {
  const width = parseFloat(widthPercent);
  return PixelRatio.roundToNearestPixel((windowWidth * width) / 100);
};

export const defaultFontSize = 26 * fontScale;

export const isIos = Platform.OS === 'ios';
export const isAndroid = Platform.OS === 'android';
export const isWeb = Platform.OS === 'web';

if (isAndroid) {
  UIManager.setLayoutAnimationEnabledExperimental(true);
}

export const backgroundColor = 'white';
export const transparantBackgroundColor = '#ffffff00';
export const sectionBackgroundColor = '#f2f2f2';
export const fontColor = undefined;
export const selectionColor = '#5ed4d4';
export const selectionFontColor: string = '#1db3b3';
export const selectionBorderColor = '#1db3b3';
export const selectionBackgroundColor = '#c9ffff';
export const disabledFieldFontColor: string = '#444444ff';
export const disabledSelectionFontColor: string = '#ddddddff';
export const fieldBorderColor = '#ddddddff';
export const recordingFontColor: string = '#ff0000';

const fieldMinWidth = 100;

const tile = {
  height: 70 * fontScale,
  alignItems: 'center',
  justifyContent: 'center',
  paddingHorizontal: 5 * fontScale,
  marginHorizontal: 5 * fontScale,
  minWidth: 150 * fontScale,
  marginVertical: 5 * fontScale,
  backgroundColor: 'white',
  borderRadius: 10 * fontScale,
  shadowRadius: 4 * fontScale,
  shadowColor: 'black',
  shadowOpacity: 0.3,
  shadowOffset: {
    height: 10 * fontScale,
    width: 3 * fontScale,
  },
  borderWidth: 2 * fontScale,
  borderColor: backgroundColor,
};

const flow = {
  flexDirection: 'row',
  flexWrap: 'wrap',
  justifyContent: 'center',
  alignItems: 'flex-start',
};

export const styles = StyleSheet.create({
  screeen: {
    flex: 100,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'stretch',
    backgroundColor: backgroundColor,
  },
  centeredScreenLayout: {
    flex: 100,
    flexDirection: 'row',
    alignItems: 'stretch',
    justifyContent: 'center',
    backgroundColor: backgroundColor,
  },
  page: {
    flex: 100,
    flexDirection: 'column',
    backgroundColor: backgroundColor,
  },
  scrollviewContainer: {
    position: 'relative',
    flex: 1,
    backgroundColor: backgroundColor,
  },
  scrollviewFixed: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
  },
  snackbarFixed: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    zIndex: 1,
  },
  paragraph: {
    flex: 100,
    flexDirection: 'column',
    marginHorizontal: 10 * fontScale,
  },
  paragraphBorder: {
    flex: 100,
    flexDirection: 'column',
    marginHorizontal: 10 * fontScale,
  },
  sideMenu: {
    padding: 10 * fontScale,
    width: 180 * fontScale,
    backgroundColor: '#1db3b3',
    shadowColor: 'gray',
    shadowOpacity: 0.7,
    justifyContent: 'flex-start',
    alignItems: 'center',
  },
  sideMenuList: {
    padding: 6 * fontScale,
    maxWidth: 160 * fontScale,
    justifyContent: 'flex-start',
  },
  findResults: {
    flex: 0,
    flexDirection: 'column',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    padding: 6 * fontScale,
  },
  h1: {
    fontSize: 40 * fontScale,
    textAlign: 'center',
    margin: 10 * fontScale,
  },
  h2: {
    fontSize: 30 * fontScale,
    textAlign: 'center',
    margin: 10 * fontScale,
  },
  h3: {
    fontSize: 25 * fontScale,
    textAlign: 'center',
    margin: 10 * fontScale,
  },
  screenTitle: {
    fontSize: defaultFontSize,
    fontWeight: '500',
    textAlign: 'center',
    margin: 12 * fontScale,
    marginTop: 30 * fontScale,
  },
  screenTitleSelected: {
    fontSize: defaultFontSize,
    textAlign: 'center',
    margin: 8 * fontScale,
    color: selectionFontColor,
  },
  sectionTitle: {
    fontSize: 24 * fontScale,
    color: selectionFontColor,
    fontWeight: '500',
    textAlign: 'center',
    margin: 6 * fontScale,
  },
  borderSectionTitle: {
    position: 'absolute',
    bottom: -12 * fontScale,
    right: 65 * fontScale,
    fontSize: 24 * fontScale,
    color: selectionFontColor,
    fontWeight: '500',
    textAlign: 'center',
    margin: 10 * fontScale,
  },
  modalTitle: {
    fontSize: 46 * fontScale,
    textAlign: 'center',
    margin: 10 * fontScale,
    color: 'white',
  },
  modalColumn: {
    flexDirection: 'column',
    flexWrap: 'wrap',
    justifyContent: 'flex-start',
    alignItems: 'center',
    marginHorizontal: 9 * fontScale,
    marginBottom: 10 * fontScale, //Weird for scroll list
    borderRightWidth: 3 * fontScale,
    borderColor: 'white',
    paddingRight: 10 * fontScale,
  },
  modalCamera: {
    flexDirection: 'column',
    flexWrap: 'wrap',
    justifyContent: 'flex-start',
    alignItems: 'center',
  },
  modalKeypadColumn: {
    flexDirection: 'column',
    flexWrap: 'wrap',
    justifyContent: 'flex-start',
    alignItems: 'center',
    marginHorizontal: 1 * fontScale,
    marginBottom: 10 * fontScale, //Weird for scroll list
  },
  modalTileLabel: modalTileLabel(false),
  modalTileLabelSelected: modalTileLabel(true),
  modalTileIcon: modalTileLabel(false, true),
  boldText: {
    fontWeight: 'bold',
  },
  text: {
    fontSize: 17 * fontScale,
  },
  iconMargin: {
    marginRight: 3 * fontScale,
    marginTop: 3 * fontScale,
  },
  grayedText: {
    fontSize: 18 * fontScale,
    color: 'gray',
  },
  linkText: {
    color: selectionFontColor,
    fontSize: 17 * fontScale,
  },
  noAccessText: {
    fontSize: 18 * fontScale,
    fontStyle: 'italic',
  },
  textLeftNoWidth: {
    fontSize: 18 * fontScale,
    textAlign: 'left',
  },
  textLeft: {
    fontSize: 18 * fontScale,
    maxWidth: 400 * fontScale,
    textAlign: 'left',
  },
  textRight: {
    fontSize: 17 * fontScale,
    alignSelf: 'flex-end',
    color: '#808080',
  },
  label: {
    fontSize: 28 * fontScale,
    padding: 10 * fontScale,
  },
  chooseButton: {
    alignItems: 'center',
    justifyContent: 'center',
    borderColor: 'gray',
    borderWidth: 1,
    borderRadius: 2,
    padding: 10 * fontScale,
    marginLeft: 10 * fontScale,
  },

  checkButtonLayout: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    margin: 0 * fontScale,
  },
  checkButtonLabel: {
    fontSize: 18 * fontScale,
    textAlign: 'center',
    color: fontColor,
  },
  multiCheckButtonLabel: {
    fontSize: 25 * fontScale,
    textAlign: 'center',
    color: fontColor,
  },
  checkButtonRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 5,
  },
  checkButtonIcon: {
    fontSize: 36 * fontScale,
    textAlign: 'center',
    marginHorizontal: 5 * fontScale,
  },
  instructionText: {
    fontSize: 24 * fontScale,
    padding: 10 * fontScale,
  },
  textfield: {
    padding: defaultFontSize * (isIos ? 1 : 0.2),
    fontSize: defaultFontSize,
    textAlign: 'center',
    borderRadius: 6 * fontScale,
    shadowRadius: 3 * fontScale,
  },
  searchField: {
    fontSize: defaultFontSize,
    height: (26 + 15) * fontScale,
    padding: 6 * fontScale,
    paddingLeft: 18 * fontScale,
    textAlign: 'left',
    backgroundColor: 'white',
    borderWidth: 1 * fontScale,
    borderRadius: 6 * fontScale,
    borderColor: fieldBorderColor,
  },
  field400: {
    fontSize: defaultFontSize,
    height: (26 + 15) * fontScale,
    minWidth: 375 * fontScale,
    padding: 6 * fontScale,
    paddingLeft: 18 * fontScale,
    textAlign: 'left',
    backgroundColor: 'white',
    borderWidth: 1 * fontScale,
    borderRadius: 6 * fontScale,
    borderColor: fieldBorderColor,
    margin: 3 * fontScale,
  },

  dropdownButtonIos: {
    fontSize: defaultFontSize,
    padding: 10 * fontScale,
    textAlign: 'center',
    borderColor: 'gray',
    borderWidth: 0,
  },
  picker: {
    padding: 10 * fontScale,
    borderColor: 'gray',
    borderWidth: 1 * fontScale,
    borderRadius: 6 * fontScale,
  },
  button: {
    padding: 16 * fontScale,
    marginHorizontal: 13 * fontScale,
    marginVertical: 6 * fontScale,
    backgroundColor: '#1db3b3',
    borderRadius: 30 * fontScale,
  },
  buttonDisabled: {
    padding: 16 * fontScale,
    marginHorizontal: 13 * fontScale,
    marginVertical: 6 * fontScale,
    backgroundColor: '#90e0e0',
    borderRadius: 30 * fontScale,
  },
  buttonText: {
    fontSize: 20 * fontScale,
    backgroundColor: '#1db3b3',
    color: 'white',
  },
  buttonDisabledText: {
    fontSize: 20 * fontScale,
    backgroundColor: '#90e0e0',
    color: 'white',
  },
  fabButtonText: {
    fontSize: 20 * fontScale,
    color: 'white',
  },
  pickerLinkButton: {
    color: selectionFontColor,
    textAlign: 'center',
    padding: 10 * fontScale,
    fontSize: defaultFontSize,
    fontWeight: 'bold',
  },
  linkButton: {
    color: selectionFontColor,
    textAlign: 'center',
    padding: 10 * fontScale,
    fontSize: 22 * fontScale,
  },
  menuButton: {
    width: 130 * fontScale,
    height: 100 * fontScale,
    borderRadius: 65 * fontScale,
    marginVertical: 20 * fontScale,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#2dc3c3',
  },
  loadMoreContainer: {
     marginTop: 16 * fontScale,
     padding: 10 * fontScale,
     alignItems: 'center',
     justifyContent: 'center',
  },
  loadMoreText: {
    color: '#1db3b3',
    fontSize: 22 * fontScale,

 },
  menuIcon: {
    color: 'white',
    fontSize: 50 * fontScale,
  },
  menuIcon2: {
    color: 'white',
    fontSize: 35 * fontScale,
    padding: 25 * fontScale,
  },
  addButton: {
    width: 60 * fontScale,
    height: 60 * fontScale,
    borderRadius: 30 * fontScale,
    padding: 5 * fontScale,
    marginHorizontal: 20 * fontScale,
    marginVertical: 3 * fontScale,
    backgroundColor: 'orange',
  },
  rowLayout: {
    display: 'flex',
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  flexRow: {
    flex: 100,
    flexDirection: 'row',
  },
  fieldContainer: {
    flexDirection: 'row',
    minWidth: fieldMinWidth * fontScale,
  },
  fieldFlexContainer: {
    flex: 100,
    flexDirection: 'row',
  },
  fieldFlexContainer2: {
    flex: 200,
    flexDirection: 'row',
  },
  flexColumnLayout: {
    flex: 100,
    flexDirection: 'column',
    justifyContent: 'flex-start',
  },
  centeredRowLayout: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    margin: 0 * fontScale,
  },
  columnLayout: {
    flex: isWeb ? 1 : 0,
    flexDirection: 'column',
    justifyContent: 'flex-start',
  },
  leftColumnLayout: {
    flex: 0,
    flexDirection: 'column',
    justifyContent: 'flex-start',
    alignItems: 'flex-start',
  },
  centeredColumnLayout: {
    flexDirection: 'column',
    alignItems: isWeb ? 'stretch' : 'center',
    justifyContent: 'center',
    margin: 0 * fontScale,
  },
  examPreview: {
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignItems: 'flex-start',
  },
  form: {
    minHeight: 170 * fontScale,
    flexDirection: 'column',
    justifyContent: 'flex-start',
    padding: 10 * fontScale,
    borderRadius: 1 * fontScale,
    margin: 10 * fontScale,
    backgroundColor: '#fff',
    shadowRadius: 3,
    shadowColor: '#000000',
    shadowOpacity: 0.3,
    shadowOffset: {
      height: 1,
      width: 0.3,
    },
  },
  formRow: {
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignItems: 'flex-start',
    padding: 3 * fontScale,
  },
  formColumn: {
    flexDirection: 'column',
    justifyContent: 'flex-start',
    alignItems: 'flex-start',
    padding: 3 * fontScale,
  },
  get formColumnFlex() {
    return {
      ...this.formColumn,
      flex: 1,
    };
  },
  set formColumnFlex(object) {},
  get FormColumnTop() {
    return {
      ...this.formColumn,
      zIndex: 9999,
    };
  },
  set FormColumnTop(object) {},
  formColumnItem: {
    width: '100%',
    height: 40 * fontScale,
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'center',
  },
  get formColumnItemHalfHeight(){
    return {...this.formColumnItem, height:20 * fontScale};
  },
  set formColumnItemHalfHeight(object){},
  formRow500: {
    width: 520 * fontScale,
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignItems: 'center',
    padding: 3 * fontScale,
  },
  widthL: {
    width: 680 * fontScale,
  },
  width800: {
    width: 840 * fontScale,
  },
  width1000: {
    width: 1040 * fontScale,
  },
  width1200: {
    width: 1240 * fontScale,
  },
  formRowL: {
    width: 680 * fontScale,
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignItems: 'center',
    padding: 3 * fontScale,
  },
  formRow800: {
    width: 840 * fontScale,
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignItems: 'center',
    padding: 3 * fontScale,
  },
  formRow1000: {
    width: 1040 * fontScale,
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignItems: 'center',
    padding: 3 * fontScale,
  },
  formRow1200: {
    width: 1240 * fontScale,
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignItems: 'center',
    padding: 3 * fontScale,
  },
  formRow1600: {
    width: 1640 * fontScale,
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignItems: 'center',
    padding: 3 * fontScale,
  },
  formElement: {
    flex: 100,
    flexDirection: 'row',
    alignItems: 'center',
  },
  formElement2: {
    flex: 200,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 3 * fontScale,
  },
  placeholderElement: {
    flex: 200,
    flexDirection: 'column',
    alignItems: 'center',
  },
  formLabel: {
    fontSize: 18 * fontScale,
    padding: 3 * fontScale,
  },
  formPrefix: {
    fontSize: 18 * fontScale,
    marginTop: 4.5 * fontScale,
    padding: 1.5 * fontScale,
    textAlign: 'right',
  },
  formSuffix: {
    fontSize: 18 * fontScale,
    marginTop: 6.5 * fontScale,
    padding: 1.5 * fontScale,
    textAlign: 'left',
  },
  formField: {
    flex: 100,
    fontSize: 20 * fontScale,
    height: 36 * fontScale,
    paddingTop: 6 * fontScale,
    paddingBottom: 4 * fontScale,
    paddingLeft: 6 * fontScale,
    paddingRight: 3 * fontScale,
    textAlign: 'left',
    backgroundColor: transparantBackgroundColor,
    borderWidth: 1 * fontScale,
    borderRadius: 6 * fontScale,
    borderColor: fieldBorderColor,
    margin: 3 * fontScale,
    width: '100%',
    textWrap: 'nowrap',
    overflow: 'hidden',
  },
  formFieldError: {
    flex: 100,
    fontSize: 20 * fontScale,
    height: 36 * fontScale,
    paddingTop: 6 * fontScale,
    paddingBottom: 4 * fontScale,
    paddingLeft: 6 * fontScale,
    paddingRight: 3 * fontScale,
    textAlign: 'left',
    backgroundColor: 'white',
    borderWidth: 2 * fontScale,
    borderRadius: 6 * fontScale,
    borderColor: '#ff0000',
    margin: 3 * fontScale,
    width: '100%',
    textWrap: 'nowrap',
    overflow: 'hidden',
  },
  formFieldReadOnly: {
    flex: 100,
    color: disabledFieldFontColor,
    fontSize: 20 * fontScale,
    height: 36 * fontScale,
    paddingTop: 6 * fontScale,
    paddingBottom: 4 * fontScale,
    paddingLeft: 6 * fontScale,
    paddingRight: 3 * fontScale,
    textAlign: 'left',
    backgroundColor: transparantBackgroundColor,
    borderWidth: 1 * fontScale,
    borderRadius: 6 * fontScale,
    borderColor: fieldBorderColor,
    margin: 3 * fontScale,
    width: '100%',
    textWrap: 'nowrap',
    overflow: 'hidden',
  },
  formFieldReadOnlyLines: {
    color: disabledFieldFontColor,
    flex: 100,
    fontSize: 20 * fontScale,
    height: 36 * 4.7 * fontScale,
    paddingTop: 6 * fontScale,
    paddingBottom: 4 * fontScale,
    paddingLeft: 6 * fontScale,
    paddingRight: 3 * fontScale,
    textAlign: 'left',
    backgroundColor: transparantBackgroundColor,
    borderWidth: 1 * fontScale,
    borderRadius: 6 * fontScale,
    borderColor: fieldBorderColor,
    margin: 3 * fontScale,
    width: '100%',
  },
  translateField: {
    borderColor: 'purple',
    borderWidth: 1 * fontScale,
    padding: 3 * fontScale,
    minWidth: 80 * fontScale,
  },
  formFieldLines: {
    flex: 1,
    fontSize: 20 * fontScale,
    minWidth: 100 * fontScale,
    height: 36 * 4.7 * fontScale,
    paddingTop: 6 * fontScale,
    paddingBottom: 4 * fontScale,
    paddingLeft: 6 * fontScale,
    paddingRight: 20 * fontScale,
    textAlign: 'left',
    backgroundColor: transparantBackgroundColor,
    borderWidth: 1 * fontScale,
    borderRadius: 6 * fontScale,
    borderColor: fieldBorderColor,
    margin: 3 * fontScale,
    width: '100%',
  },
  formValidationError: {
    fontSize: 20 * fontScale,
    color: 'red',
    position: 'absolute',
    bottom: 7 * fontScale,
    right: 7 * fontScale,
    textAlign: 'right',
    backgroundColor: '#ffffffcc',
  },
  helperTextError:{
    position: 'relative',
    top: -10 * fontScale,
    color: 'red',
    paddingLeft: 20 * fontScale,
    fontSize: 16 * fontScale
  },
  inputField: inputFieldStyle(false, false),
  inputFieldActive: inputFieldStyle(true, false),
  inputFieldActiveChanged: inputFieldStyle(true, true),
  formTableRowHeader: {
    flex: 65,
    fontSize: 18 * fontScale,
    paddingHorizontal: 3 * fontScale,
    textAlign: 'right',
    margin: 5 * fontScale,
    maxWidth: 'max-content',
  },
  formTableColumnHeader: {
    flex: 100,
    flexDirection: 'row',
    fontSize: 18 * fontScale,
    textAlign: 'center',
    margin: 4 * fontScale,
    marginTop: 20 * fontScale,
    marginBottom: 0 * fontScale,
  },
  formTablePrismColumnHeader: {
    flex: 100,
    flexDirection: 'row',
    fontSize: 18 * fontScale,
    textAlign: 'center',
    margin: 4 * fontScale,
    marginTop: 20 * fontScale,
    marginBottom: 0 * fontScale,
    minWidth: 170
  },
  formTableColumnHeaderWide: {
    flex: 240,
    flexDirection: 'row',
    fontSize: 20 * fontScale,
    textAlign: 'center',
    margin: 4 * fontScale,
    marginTop: 20 * fontScale,
    marginBottom: 0 * fontScale,
  },
  formTableColumnHeaderSmall: {
    maxWidth: 24,
    minWidth: 24,
  },
  formTableColumnHeaderFlat: {
    width: 0 * fontScale,
  },
  buttonsRowLayout: {
    flex: 0,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 5 * fontScale,
  },
  buttonsRowStartLayout: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'flex-start',
  },
  comboBox: {
    borderColor: 'gray',
    borderWidth: 1,
  },
  card: cardStyle('white'),
  card0: cardStyle('purple'),
  card1: cardStyle('blue'),
  card2: cardStyle('gray'),
  card3: cardStyle('red'),
  card4: cardStyle('yellow'),
  card5: cardStyle('green'),
  cardTitle: {
    fontSize: 21 * fontScale,
    fontWeight: '500',
    textAlign: 'center',
    margin: 10 * fontScale,
  },
  cardTitleLeft: {
    fontSize: 21 * fontScale,
    fontWeight: '500',
    textAlign: 'left',
    margin: 0 * fontScale,
  },
  cardSubTitle: {
    fontSize: 17 * fontScale,
    fontWeight: 'bold',
    alignItems: 'center',
    marginTop: 1 * fontScale,
  },
  cardColumn: {
    marginHorizontal: 3 * fontScale,
    alignItems: 'flex-start',
    marginBottom: 6 * fontScale,
  },
  popup: {
    padding: 20 * fontScale,
    borderRadius: 10 * fontScale,
    margin: 10 * fontScale,
    backgroundColor: 'white',
    shadowRadius: 4 * fontScale,
    shadowColor: '#000000',
    shadowOpacity: 0.3,
    shadowOffset: {
      height: 10 * fontScale,
      width: 3 * fontScale,
    },
  },
  popupBackground: {
    flex: 100,
    backgroundColor: '#00000077',
    padding: 20 * fontScale,
  },
  popupTile: {
    ...tile,
  },
  readOnly: {
    ...tile,
    backgroundColor: 'gray',
  },
  popupTileSelected: {
    ...tile,
    backgroundColor: selectionBackgroundColor,
    borderColor: selectionBorderColor,
  },
  nextTile: {
    position: 'absolute',
    bottom: 0 * fontScale,
    right: 8 * fontScale,
    ...tile,
  },
  previousTile: {
    position: 'absolute',
    bottom: 0 * fontScale,
    left: 8 * fontScale,
    ...tile,
  },
  tabHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 5 * fontScale,
  },
  tabFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 5 * fontScale,
  },
  tab: tabStyle(false),
  selectedTab: tabStyle(true),
  tabText: {
    fontSize: 18 * fontScale,
    flexWrap: 'nowrap',
    color: selectionFontColor,
    textShadowColor: selectionColor,
    textShadowRadius: 0 * fontScale,
    textShadowOffset: {
      height: 0.3 * fontScale,
      width: 0.5 * fontScale,
    },
  },
  tabTextSelected: {
    fontSize: 18 * fontScale,
    color: 'white',
    flexWrap: 'nowrap',
  },

  tabCardFollowUp: {
    flex: 100,
    flexDirection: 'column',
    justifyContent: 'flex-start',
    padding: 10 * fontScale,
    paddingBottom: 40 * fontScale,
    minHeight: 200 * fontScale,
    minWidth: 333 * fontScale,
    borderRadius: 30 * fontScale,
    borderColor: selectionFontColor,
    borderWidth: 2 * fontScale,
    margin: 7 * fontScale,
  },

  tabCard: {
    flexGrow: 100,
    padding: 10 * fontScale,
    paddingBottom: 40 * fontScale,
    minHeight: 260 * fontScale,
    minWidth: 333 * fontScale,
    borderRadius: 30 * fontScale,
    borderColor: selectionFontColor,
    borderWidth: 2 * fontScale,
    margin: 7 * fontScale,
  },
  tabCardS: {
    flexGrow: 100,
    padding: 20 * fontScale,
    minHeight: 100 * fontScale,
    borderRadius: 30 * fontScale,
    borderColor: selectionFontColor,
    borderWidth: 2 * fontScale,
    margin: 7 * fontScale,
  },
  errorCard: {
    flexGrow: 0,
    padding: 15 * fontScale,
    paddingLeft: 50 * fontScale,
    minHeight: 40 * fontScale,
    borderRadius: 30 * fontScale,
    borderColor: 'red',
    borderWidth: 3 * fontScale,
    margin: 7 * fontScale,
  },
  warningPanel: {
    flexGrow: 0,
    padding: 15 * fontScale,
    minHeight: 40 * fontScale,
    backgroundColor: 'red',
  },
  buttonsCard: {
    padding: 10 * fontScale,
    paddingBottom: 40 * fontScale,
    borderRadius: 30 * fontScale,
    borderColor: selectionFontColor,
    borderWidth: 2 * fontScale,
    margin: 7 * fontScale,
  },
  columnCard: {
    flex: 30,
    flexGrow: 30,
    minWidth: 240 * fontScale,
    padding: 10 * fontScale,
    minHeight: 260 * fontScale,
    borderRadius: 30 * fontScale,
    borderColor: selectionFontColor,
    borderWidth: 2 * fontScale,
    margin: 7 * fontScale,
  },
  examsBoard: {
    backgroundColor: sectionBackgroundColor,
    flexGrow: 100,
    minWidth: 250 * fontScale,
    minHeight: 190 * fontScale,
    padding: 10 * fontScale,
    paddingBottom: 20 * fontScale,
    borderRadius: 30 * fontScale,
    borderColor: selectionFontColor,
    borderWidth: 2 * fontScale,
    margin: 7 * fontScale,
    flexShrink: isWeb ? 100 : 0,
  },
  startVisitCard: {
    backgroundColor: sectionBackgroundColor,
    flexGrow: 100,
    padding: 10 * fontScale,
    paddingBottom: 40 * fontScale,
    minHeight: 160 * fontScale,
    minWidth: 333 * fontScale,
    borderRadius: 30 * fontScale,
    borderColor: selectionFontColor,
    borderWidth: 2 * fontScale,
    margin: 7 * fontScale,
  },
  flow: flow,
  flowLeft: {
    justifyContent: 'flex-start',
    ...flow,
  },
  flowLeft1: {
    justifyContent: 'flex-start',
    flex: 100,
    ...flow,
  },
  flow1: {
    flex: 100,
    ...flow,
  },
  flow2: {
    flex: 200,
    ...flow,
  },
  flow3: {
    flex: 300,
    ...flow,
  },
  topFlow: {
    ...flow,
    justifyContent: 'flex-start',
    alignItems: 'flex-start',
  },
  topFlow2: {
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingLeft: 10 * fontScale,
    paddingRight: 10 * fontScale,
  },
  verticalFlow: {
    flexDirection: 'column',
    flexWrap: 'wrap',
    justifyContent: 'flex-start',
    alignItems: 'flex-start',
  },
  examCard: examCardStyle('gray'),
  todoExamCard: examCardStyle('orange'),
  finishedExamCard: examCardStyle('green'),
  unverifiedExamCard: examCardStyle('red'),
  board: boardStyle('#dddddd'),
  boardFixedWidth: boardFixedWidthStyle(),
  boardSelected: boardStyle(selectionBorderColor),
  boardS: boardStyle('#dddddd', 'S'),
  boardM: boardStyle('#dddddd', 'M'),
  boardL: boardStyle('#dddddd', 'L'),
  boardXL: boardStyle('#dddddd', 'XL'),
  boardMAX: boardStyle('#dddddd', 'MAX'),
  boardTodo: boardStyle('#ffaabb'),
  boardTodoS: boardStyle('#ffaabb', 'S'),
  boardTodoM: boardStyle('#ffaabb', 'M'),
  boardTodoL: boardStyle('#ffaabb', 'L'),
  boardTodoXL: boardStyle('#ffaabb', 'XL'),
  historyBoard: boardStyle(backgroundColor, 'L', 278),
  historyBoardSelected: boardStyle(selectionBorderColor, 'L', 278),
  boardStretch: {
    width: 530 * fontScale,
    height: isWeb ? undefined : 285 * fontScale,
    maxHeight: isWeb ? 585 * fontScale : undefined,
    padding: 10 * fontScale,
    borderRadius: 30 * fontScale,
    borderColor: '#dddddd',
    borderWidth: 3 * fontScale,
    margin: 7 * fontScale,
    shadowRadius: 3 * fontScale,
    shadowColor: '#dddddd',
    shadowOpacity: 0.9,
    shadowOffset: {
      height: 0.3,
      width: 0.3,
    },
  },
  boardStretchL: {
    flexShrink: 1,
    width: 1080 * fontScale,
    height: isWeb ? undefined : 285 * fontScale,
    maxHeight: isWeb ? 585 * fontScale : undefined,
    padding: 10 * fontScale,
    borderRadius: 30 * fontScale,
    borderColor: '#dddddd',
    borderWidth: 3 * fontScale,
    margin: 7 * fontScale,
    shadowRadius: 3 * fontScale,
    shadowColor: '#dddddd',
    shadowOpacity: 0.9,
    shadowOffset: {
      height: 0.3,
      width: 0.3,
    },
  },
  wrapBoard: {
    flex: 0,
    flexDirection: 'column',
    flexWrap: 'wrap',
    justifyContent: 'flex-start',
    alignItems: 'flex-start',
    maxHeight: 245 * fontScale,
    padding: 5 * fontScale,
    margin: 0 * fontScale,
  },
  wideFavorites: {
    flexShrink: 1,
    width: 1080 * fontScale,
    height: isWeb ? undefined : 145 * fontScale,
    padding: 10 * fontScale,
    borderRadius: 30 * fontScale,
    borderColor: '#dddddd',
    borderWidth: 3 * fontScale,
    margin: 7 * fontScale,
    shadowRadius: 3 * fontScale,
    shadowColor: '#dddddd',
    shadowOpacity: 0.9,
    shadowOffset: {
      height: 0.3,
      width: 0.3,
    },
  },
  store: {
    flex: 80,
    flexDirection: 'row',
    flexWrap: 'wrap',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 30 * fontScale,
    borderColor: 'white',
    borderWidth: 3 * fontScale,
    margin: 7 * fontScale,
    shadowRadius: 8,
    shadowColor: 'white',
    shadowOpacity: 1,
  },
  room: {
    minWidth: 150 * fontScale,
    minHeight: 250 * fontScale,
    margin: 20 * fontScale,
    padding: 3 * fontScale,
    alignItems: 'center',
    backgroundColor: '#D7D7FF',
  },
  bottomRight: {
    position: 'absolute',
    bottom: 15 * fontScale,
    right: 8 * fontScale,
  },
  topRight: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  bgRow: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    marginBottom: 5,
    padding: 5,
  },
  bgRowWeb: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    marginBottom: '5px',
    padding: '5px',
  },
  billingView: {maxWidth: 300},
  listRow: {
    flex: 10,
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignItems: 'flex-start',
    padding: 10 * fontScale,
    backgroundColor: 'white',
    margin: 3 * fontScale,
  },
  listRowWithSubheader: {
    flex: 10,
    flexDirection: 'column',
    justifyContent: 'flex-start',
    alignItems: 'flex-start',
    padding: 10 * fontScale,
    margin: 3 * fontScale,
    lineHeight: 1.5 * fontScale,
  },
  listSubheader: {
    fontSize: 18 * fontScale,
    display: 'block',
    color: 'gray',
    flex: 'auto'
  },
  container: {
    flex: 1,
    justifyContent: 'center',
  },
  listRowSelected: {
    flex: 10,
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignItems: 'flex-start',
    padding: 10 * fontScale,
    backgroundColor: selectionColor,
    margin: 3 * fontScale,
  },
  listText: {
    fontSize: 18 * fontScale,
    flexWrap: 'nowrap',
    textAlign: 'left',
  },
  listTextSelected: {
    fontSize: 18 * fontScale,
    fontWeight: 'bold',
    flexWrap: 'nowrap',
    textAlign: 'left',
    color: selectionFontColor,
  },
  listTextGrey: {
    fontSize: 18 * fontScale,
    flexWrap: 'nowrap',
    textAlign: 'left',
    color: '#808080',
  },

  tableListText: {
    flex: 100,
    flexDirection: 'row',
    fontSize: 18 * fontScale,
    flexWrap: 'nowrap',
    textAlign: 'left',
    margin: 4 * fontScale,
  },
  tableListTextSelected: {
    flex: 100,
    flexDirection: 'row',
    fontSize: 18 * fontScale,
    flexWrap: 'nowrap',
    textAlign: 'left',
    margin: 4 * fontScale,
    color: selectionFontColor,
  },

  scrollPopup: {
    position: 'absolute',
    top: 10 * fontScale,
    height: 140 * fontScale,
    left: 40,
    width: windowWidth - 40 * 2,
    borderRadius: 4 * fontScale,
    backgroundColor: '#ffffffee',
    shadowRadius: 4 * fontScale,
    shadowColor: '#000000',
    shadowOpacity: 0.3,
    shadowOffset: {
      height: 6 * fontScale,
      width: 3 * fontScale,
    },
  },
  rulerIndicator: {
    width: 1 * fontScale,
    height: 40 * fontScale,
    backgroundColor: 'red',
  },
  solidWhite: {
    backgroundColor: 'white',
  },
  flag: {
    position: 'absolute',
    top: 0 * fontScale,
    right: 15 * fontScale,
    backgroundColor: '#00000000',
  },
  flagFont: {
    fontSize: 30 * fontScale,
    padding: 20 * fontScale,
  },
  version: {
    position: 'absolute',
    bottom: 20 * fontScale,
    right: 20 * fontScale,
    fontSize: 14 * fontScale,
  },
  versionFont: {
    fontSize: 14 * fontScale,
  },
  screenIcon: {
    padding: 25 * fontScale,
    fontSize: 30 * fontScale,
  },
  groupIcon: {
    padding: 15 * fontScale,
    fontSize: 27 * fontScale,
  },
  voiceIconMulti: {
    padding: 25 * fontScale,
    paddingVertical: 40 * fontScale,
    fontSize: 45 * fontScale,
    margin: -20 * fontScale,
  },
  voiceIcon: {
    padding: 25 * fontScale,
    paddingVertical: 20 * fontScale,
    fontSize: 45 * fontScale,
    margin: -20 * fontScale,
  },
  textIcon: {
    padding: 0 * fontScale,
    fontSize: 25 * fontScale,
  },
  examIcons: {
    position: 'absolute',
    top: 0 * fontScale,
    right: -10 * fontScale,
    flexDirection: 'row',
  },
  examIconsFlex: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    width: '100%',
  },
  imageContainer: {
    flexDirection: 'row',
  },
  drawingIcons: {
    position: 'absolute',
    right: -5 * fontScale,
    justifyContent: 'center',
    flexDirection: 'column',
    backgroundColor: '#ffffffbb',
  },
  drawIcon: {
    padding: 20 * fontScale,
    fontSize: 27 * fontScale,
  },
  groupIcons: {
    position: 'absolute',
    top: 0 * fontScale,
    right: 15 * fontScale,
    width: 200 * fontScale,
    flexDirection: 'row-reverse',
  },
  groupExtraIcons: {
    position: 'absolute',
    top: 0 * fontScale,
    left: 15 * fontScale,
    width: 200 * fontScale,
    flexDirection: 'row',
  },
  separator: {
    marginTop: 10 * fontScale,
  },
  popupFullScreen: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5FCFF',
  },
  scanner: {
    width: 600 * fontScale,
    height: 800 * fontScale,
    borderColor: 'orange',
    borderWidth: 1,
  },
  scannedImage: {
    width: (windowWidth - 620) * fontScale,
    height: 800 * fontScale,
  },
  floatingContainer: {
    position: 'absolute',
    bottom: 0 * fontScale,
    right: 0 * fontScale,
    width: 210 * fontScale,
  },
  floatingButton: {
    position: 'absolute',
    bottom: 2 * fontScale,
    right: 2 * fontScale,
    backgroundColor: 'orange',
    borderRadius: 30 * fontScale,
  },
  floatingSubButton: {
    flex: 1,
    width: null,
    shadowOpacity: 0.3,
    shadowOffset: {
      height: 6 * fontScale,
      width: 2 * fontScale,
    },
    backgroundColor: 'orange',
  },
  copyColumnContainer: {
    position: 'absolute',
    width: 56 * fontScale,
    left: -28 * fontScale,
    textAlign: 'center',
  },
  bottomEndOfRow: {
    position: 'absolute',
    bottom: 0 * fontScale,
    right: 0 * fontScale,
  },
  copyRow: {
    fontSize: 28 * fontScale,
    fontWeight: 'normal',
    borderWidth: 0,
    textAlign: 'center',
    transform: [{rotate: '90deg'}],
  },
  copyColumn: {
    fontSize: 28 * fontScale,
    fontWeight: 'normal',
    borderWidth: 0,
    padding: 8 * fontScale,
    textAlign: 'center',
  },
  patientDocument: {
    flex: 1,
    height: 1000 * fontScale,
    margin: 10 * fontScale,
    marginRight: 15 * fontScale,
    backgroundColor: sectionBackgroundColor,
  },
  assessmentCard: {
    padding: 10 * fontScale,
    borderRadius: 3 * fontScale,
    margin: 10 * fontScale,
    backgroundColor: sectionBackgroundColor,
    shadowRadius: 8 * fontScale,
    shadowColor: selectionColor,
    shadowOpacity: 0.3,
    shadowOffset: {
      height: 3 * fontScale,
      width: 1 * fontScale,
    },
  },
  pageEditor: {
    flexDirection: 'column',
    flex: 7,
    flexGrow: 1,
    minWidth: 650,
    maxWidth: 650,
    minHeight: windowHeight - 120 * fontScale,
    backgroundColor: 'white',
    alignSelf: 'flex-start',
    padding: 0 * fontScale,
    borderColor: fieldBorderColor,
    borderWidth: 3 * fontScale,
    margin: 7 * fontScale,
    shadowRadius: 3 * fontScale,
    shadowColor: fieldBorderColor,
    shadowOpacity: 0.9,
    shadowOffset: {
      height: 0.3,
      width: 0.3,
    },
  },
  sideBar: {
    flexDirection: 'column',
    minWidth: 290 * fontScale,
    maxWidth: 400 * fontScale,
    minHeight: 300 * fontScale,
    margin: 7 * fontScale,
    borderColor: fieldBorderColor,
    borderWidth: 3 * fontScale,
    shadowRadius: 3 * fontScale,
    shadowColor: fieldBorderColor,
    shadowOpacity: 0.9,
    shadowOffset: {
      height: 0.3,
      width: 0.3,
    },
  },
  sideBarHorizontal: {
    flexDirection: 'row',
    minWidth: 290 * fontScale,
    maxWidth: 600 * fontScale,
    minHeight: 50 * fontScale,
    maxHeight: 80 * fontScale,
    margin: 7 * fontScale,
    borderColor: fieldBorderColor,
    borderWidth: 3 * fontScale,
    shadowRadius: 3 * fontScale,
    shadowColor: fieldBorderColor,
    shadowOpacity: 0.9,
    shadowOffset: {
      height: 0.3,
      width: 0.3,
    },
  },
  listSeparator: {
    backgroundColor: '#f0f0ff',
  },
  alert: {
    alignSelf: 'center',
    top: 10 * fontScale,
    backgroundColor: '#fff',
    justifyContent: 'space-between',
  },
  alertCheckBox: {
    flexDirection: 'column',
    justifyContent: 'flex-start',
    flex: 1,
    fontSize: 18 * fontScale,
    color: fontColor,
  },
  bottomBar: {
    zIndex: 1,
    minWidth: '100%',
    position: 'absolute',
    bottom: 0,
  },
  bottomItems: {
    flexDirection: 'row',
    alignItems: 'flex-end',
  },
  leftSearchColumn: {
    flex: 100,
    minWidth: 300 * fontScale,
    padding: 10 * fontScale,
    minHeight: 300 * fontScale,
    borderRadius: 30 * fontScale,
    borderColor: selectionFontColor,
    borderWidth: 2 * fontScale,
    margin: 7 * fontScale,
  },
  rightSearchColumn: {
    flex: 75,
    minWidth: 240 * fontScale,
    padding: 10 * fontScale,
    minHeight: 300 * fontScale,
    borderRadius: 30 * fontScale,
    borderColor: selectionFontColor,
    borderWidth: 2 * fontScale,
    margin: 7 * fontScale,
  },
  searchList: {
    backgroundColor: '#fff',
    flex: 75,
    minWidth: 240 * fontScale,
    padding: 10 * fontScale,
    minHeight: 260 * fontScale,
    borderRadius: 30 * fontScale,
    borderColor: selectionFontColor,
    borderWidth: 2 * fontScale,
    margin: 7 * fontScale,
  },
  searchPage: {
    backgroundColor: '#fff',
    flex: 100,
    padding: 10,
  },
  appointment: {
    flex: 100,
    justifyContent: 'center',
    alignSelf: 'flex-start',
    alignItems: 'baseline',
  },
  appointments: {
    maxHeight: 600 * fontScale,
    minWidth: 300 * fontScale,
    display: 'flex',
    flexDirection: 'column',
    flexWrap: 'nowrap',
    alignContent: 'center',
  },

  copyDialog: {
    backgroundColor: 'rgb(51, 51, 51)',
    zIndex: 1,
    minWidth: '100%',
    minHeight: 50 * fontScale,
    position: 'absolute',
    bottom: 0,
  },
  copyText: {
    color: 'white',
    fontSize: 20 * fontScale,
    padding: 10 * fontScale,
  },
  alignPopup: {
    alignItems: 'center',
  },
  AppointmentDialog: {
    width: '55%',
    alignSelf: 'center',
    backgroundColor: '#fff',
  },
  VisitTypeDialog: {
    minWidth: '30%',
    height: '50%',
    alignSelf: 'center',
    backgroundColor: '#fff',
  },
  appointmentActionButton: {
    maxWidth: 180,
    minWidth: 70 * fontScale,
    marginTop: 20,
    borderRadius: 10,
    padding: 5,
    backgroundColor: selectionFontColor,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 2,
    textAlign: 'center',
  },
  doubleBookingTimeField: {
    color: 'black',
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'center',
    marginLeft: 10 * fontScale,
  },
  doubleBookingSearchField: {
    fontSize: defaultFontSize,
    height: (26 + 15) * fontScale,
    minWidth: 80 * fontScale,
    textAlign: 'left',
    backgroundColor: 'white',
    borderWidth: 1 * fontScale,
    borderRadius: 6 * fontScale,
    marginRight: 10 * fontScale,
    borderColor: fieldBorderColor,
    paddingTop: 0,
    paddingBottom: 0,
    paddingLeft: 10 * fontScale,
    paddingRight: 10 * fontScale,
  },
  availabilitiesField: {
    shadowRadius: 0,
    paddingRight: 7 * fontScale,
    fontSize: 18 * fontScale,
    minWidth: 225 * fontScale,
    textAlign: 'justify',
  },
  paddingLeft40: {
    paddingLeft: 40 * fontScale,
  },
  summaryGroupContainer: {
    flexDirection: 'row',
    marginBottom: 10 * fontScale,
  },
  summarySubTitle: {
    fontSize: 17 * fontScale,
    fontWeight: '500',
    alignItems: 'center',
    marginTop: 1 * fontScale,
    minWidth: 150 * fontScale,
  },
  textWrap: {
    fontSize: 17 * fontScale,
    flexWrap: 'wrap',
    flexShrink: 1,
  },
  examLabel: {
    position: 'absolute',
    width: '100%',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
  },
  paddingLeftRight10: {
    paddingLeft: 10 * fontScale,
    paddingRight: 10 * fontScale,
  },
  readMoreLabel: {
    color: '#1fb3b4',
    fontWeight: 'bold',
  },

  labelTitle: {
    fontWeight: '500',
  },
  attachement: {
    minHeight: 10 * fontScale,
    flexDirection: 'column',
    justifyContent: 'flex-start',
    padding: 10 * fontScale,
    borderRadius: 1 * fontScale,
    margin: 10 * fontScale,
    backgroundColor: '#fff',
  },
  attachementContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    alignItems: 'flex-start',
    marginBottom: 20 * fontScale,
  },
  flatListScroll: {
    height: 500 * fontScale,
  },
  rowContainer: {
    flex: 1,
    width: '100%',
  },
  row: {
    flexDirection: 'row',
    width: '100%', // Ensures each row takes the full available width
  },
  contentFitColumn: {
    flexShrink: 1, // Ensures the column fits its content
    justifyContent: 'center',
    minWidth: 30,
  },
  flexColumn: {
    flex: 1, // Ensures the column flexes to fill remaining space equally
    justifyContent: 'center',
    minWidth: 30,
    flexGrow: 1,
  },
  flexPrismColumn: {
    flex: 1,
    justifyContent: 'center',
    minWidth: 170,
    flexGrow: 1,
  },
  emptyButtonSpace: {
    minWidth: 24,
  },
  emptyButtonSpaceWide: {
    minWidth: 34,
  },
  emptyButtonSpaceAlt: {
    minWidth: 24,
    position: 'absolute',
    top: 4,
    right: 0,
  },
  formTableColumnHeaderFitContent: {
    flexShrink: 0,
    flexGrow: 0,
    maxWidth: 'fit-content',
    fontSize: 18 * fontScale,
    textAlign: 'center',
    marginRight: 4 * fontScale,
  },
  formRowContainer: {
    flexDirection: 'row',
  },
  formRowHeadingsContainer: {
    flexShrink: 0,
    flexGrow: 0,
  },
  formHeadingRow: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    padding: 3 * fontScale,
  },
  formHeadingRow2: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    padding: 3 * fontScale,
    marginTop: 5 * fontScale,
  },
  formHeadingRowForCheckbox: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    padding: 3 * fontScale,
    marginTop: 2 * fontScale,
  },
  formDataContainer: {
    flex: 1,
  },
  examHistoryScreenContainer: {
    padding: 20, 
    marginBottom: 30
  },
  examHistoryScreenLoadingContainer: {
    flex: 1, 
    justifyContent:'center', 
    textAlign: 'center'
  },
  examHistoryLoadMoreBtn: {
    textAlign:'center', 
    width: 200, 
    alignSelf:'center',
    alignItems: 'center',
    justifyContent: 'center', 
    flex: 1
  },
  refreshNowContainer: {
    flexDirection: 'row', 
    justifyContent: 'flex-end', 
    alignItems: 'center',
    paddingLeft: 10 * fontScale,
    paddingRight: 10 * fontScale
  },
  refreshNowIcon: {
    marginLeft: 20 * fontScale,
    borderColor: fieldBorderColor,
    borderWidth: 1,
    borderRadius: 5,
    justifyContent: 'center', 
    alignItems: 'center',
    height: 20,
    width: 20
  }
});

function cardStyle(color: Color) {
  return {
    padding: 10 * fontScale,
    borderRadius: 3 * fontScale,
    margin: 10 * fontScale,
    backgroundColor: 'white',
    shadowRadius: 8 * fontScale,
    shadowColor: color,
    shadowOpacity: 0.3,
    shadowOffset: {
      height: 3 * fontScale,
      width: 1 * fontScale,
    },
  };
}

function tabStyle(isSelected: boolean) {
  return {
    minWidth: 130 * fontScale,
    height: 58 * fontScale,
    alignItems: 'center',
    paddingHorizontal: 14 * fontScale,
    paddingVertical: 6 * fontScale,
    borderRadius: 3 * fontScale,
    marginTop: 14 * fontScale,
    marginBottom: 8 * fontScale,
    marginLeft: 12 * fontScale,
    marginRight: 4 * fontScale,
    backgroundColor: !isSelected ? 'white' : selectionColor,
    shadowRadius: !isSelected ? 3 * fontScale : 3 * fontScale,
    shadowColor: !isSelected ? selectionColor : 'gray',
    shadowOpacity: 0.9,
    shadowOffset: {
      height: !isSelected ? 0.5 : 1,
      width: !isSelected ? 0.3 : 0.5,
    },
  };
}

function boardStyle(
  shadowColor: Color,
  size: ?string = isWeb ? 'M' : 'S',
  minHeight: ?number = 0,
) {
  const minWidth: number =
    size === 'XL' || size === 'MAX'
      ? 1040
      : size === 'L'
      ? 680
      : size === 'M'
      ? 520
      : size === 'S'
      ? 340
      : 340;
  return {
    backgroundColor: 'white',
    alignSelf: 'flex-start',
    padding: 10 * fontScale,
    paddingTop: (size === 'S' || size === 'M' ? 46 : 10) * fontScale,
    minWidth: minWidth * fontScale,
    minHeight: minHeight * fontScale,
    borderRadius: 30 * fontScale,
    borderColor: shadowColor,
    borderWidth: 3 * fontScale,
    margin: 7 * fontScale,
    shadowRadius: 3 * fontScale,
    shadowColor: shadowColor,
    shadowOpacity: 0.9,
    shadowOffset: {
      height: 0.3,
      width: 0.3,
    },
    flexGrow: 1,
    flexShrink: 1,
  };
}

function boardFixedWidthStyle() {
  let style = boardStyle('#dddddd');
  style.flexGrow = 0;
  style.flexShrink = 0;
  return style;
}

export function imageWidth(size: string): number {
  const width: number =
    size === 'XL'
      ? 1110
      : size === 'L'
      ? 680
      : size === 'M'
      ? 520
      : size === 'S'
      ? 340
      : size === 'XS'
      ? 130
      : 340;
  return width;
}

export function printWidth(size: string): number {
  return (imageWidth(size) / 1110) * 612;
}

export function imageStyle(size: string, aspecRatio: number) {
  const width: number = imageWidth(size);
  return {
    width: width * fontScale,
    height: (width * fontScale) / aspecRatio,
    resizeMode: 'contain',
  };
}

function examCardStyle(shadowColor: Color) {
  return {
    alignItems: 'center',
    justifyContent: 'flex-start',
    paddingHorizontal: 14 * fontScale,
    paddingBottom: 8 * fontScale,
    minWidth: 130 * fontScale,
    minHeight: 130 * fontScale,
    borderRadius: 10,
    margin: 10,
    backgroundColor: 'white',
    shadowRadius: 6 * fontScale,
    shadowColor: shadowColor,
    shadowOpacity: 0.6,
    shadowOffset: {
      height: 1,
      width: 0.3,
    },
  };
}

function inputFieldStyle(isActive: boolean, hasNewValue: boolean) {
  return {
    fontSize: 20 * fontScale,
    minHeight: 32 * fontScale,
    flex: 100,
    paddingHorizontal: 6 * fontScale,
    paddingVertical: 3 * fontScale,
    textAlign: 'right',
    color: hasNewValue ? 'blue' : 'black',
    backgroundColor: isActive ? '#f0f0ff' : 'white',
    borderRadius: 3 * fontScale,
    margin: 3 * fontScale,
    borderWidth: 1 * fontScale,
    borderColor: isActive ? 'blue' : 'black',
    shadowRadius: 3 * fontScale,
    shadowColor: isActive ? 'blue' : 'black',
    shadowOpacity: 0.3,
    shadowOffset: {
      height: 1,
      width: 0.3,
    },
  };
}

function modalTileLabel(isSelected: boolean, isIcon: boolean = false) {
  return {
    fontSize: (isIcon ? 36 : 26) * fontScale,
    textAlign: 'center',
    margin: (isIcon ? 5 : 8) * fontScale,
    color: isSelected ? selectionFontColor : fontColor,
    fontWeight: isSelected ? 'bold' : 'normal',
  };
}

export function scaleStyle(style: Object, isReferral?: Boolean): Object {
  // Use 0.75 if isReferral, else use globalFontScale
  const fontScale = isReferral ? 0.75 : globalFontScale;
  if (style === undefined || style === null) {
    return style;
  }
  const scaledStyle: Object = JSON.parse(JSON.stringify(style));
  if (style.fixedWidth) {
    return styles.boardFixedWidth;
  }
  if (style.top) {
    scaledStyle.top = style.top * fontScale;
  }
  if (style.left) {
    scaledStyle.left = style.left * fontScale;
  }
  if (style.right) {
    scaledStyle.right = style.right * fontScale;
  }
  if (style.bottom) {
    scaledStyle.bottom = style.bottom * fontScale;
  }
  if (style.width) {
    scaledStyle.width = style.width * fontScale;
  }
  if (style.height) {
    scaledStyle.height = style.height * fontScale;
  }

  return scaledStyle;
}

/**
 * @flow
 */
'use strict';
import moment from 'moment';
require('moment/locale/fr.js');
require('moment/locale/fr-ca.js');
require('moment/locale/es.js');
import {strings} from './Strings';
import { isWeb } from './Styles';
import { WINK_APP_REST_URL, WINK_IMAGE_URL } from '@env';

export const shortTimeFormat: string = 'H:mm';
export const timeFormat: string = 'h:mm a';
export const time24Format: string = 'HH:mm';
export const dateFormat: string = 'MMM Do';
export const officialDateFormat: string = 'YYYY-MM-DD'; //TODO: this should be locale dependent or a setting?
export const dayDateFormat: string = 'dd MMM Do';
export const farDateFormat: string = 'MMM YYYY';
export const farDateFormat2: string = 'MMMM YYYY';
export const yearDateFormat: string = 'MMM Do YYYY';
export const dayYearDateFormat: string = 'dd MMM Do YYYY';
export const dateTimeFormat: string = dateFormat + ' ' + timeFormat;
export const dayDateTimeFormat: string = dayDateFormat + ' ' + timeFormat;
export const dateTime24Format: string = dateFormat + ' ' + time24Format;
export const dayDateTime24Format: string = dayDateFormat + ' ' + time24Format;
export const yearDateTimeFormat: string = yearDateFormat + ' ' + timeFormat;
export const dayYearDateTimeFormat: string =
  dayYearDateFormat + ' ' + timeFormat;
export const yearDateTime24Format: string = yearDateFormat + ' ' + time24Format;
export const dayYearDateTime24Format: string =
  dayYearDateFormat + ' ' + time24Format;
export const jsonDateTimeFormat: string = 'YYYY-MM-DD[T]HH:mm';
export const jsonDateFormat: string = 'YYYY-MM-DD';

export function deepClone(object: any): any {
  if (object === undefined) {
    return undefined;
  }
  if (object === null) {
    return null;
  }
  return JSON.parse(JSON.stringify(object));
}

export function toDate(time: Date): Date {
  const date = new Date(time.getFullYear(), time.getMonth(), time.getDate());
  return date;
}

export function now(): Date {
  return new Date();
}

export function today(): Date {
  const today: Date = toDate(now());
  return today;
}

export function tomorrow(): Date {
  const nu: Date = now();
  const tomorrow: Date = new Date(
    nu.getFullYear(),
    nu.getMonth(),
    nu.getDate() + 1,
  );
  return tomorrow;
}

// Function To convert Title Case to camel Case
export function titleToCamelCase(str) {
  return str
    .split(' ')
    .map((word, index) => {
      word = word.toLowerCase();
      return index === 0 ? word : word.charAt(0).toUpperCase() + word.slice(1);
    })
    .join('');
}



export function addDays(date: Date, dayCount: number) {
  const newDate: Date = new Date(
    date.getFullYear(),
    date.getMonth(),
    date.getDate() + dayCount,
  );
  return newDate;
}

export function yesterday(): Date {
  const nu: Date = now();
  const yesterday: Date = new Date(
    nu.getFullYear(),
    nu.getMonth(),
    nu.getDate() - 1,
  );
  return yesterday;
}

export function isSameDay(d1: Date, d2: Date): boolean {
  return (
    d1.getFullYear() == d2.getFullYear() &&
    d1.getMonth() == d2.getMonth() &&
    d1.getDate() == d2.getDate()
  );
}

export function isSameYear(d1: Date, d2: Date): boolean {
  return d1.getFullYear() == d2.getFullYear();
}

export function isToday(date: Date | string): boolean {
  if (!(date instanceof Date)) {
    date = parseDate(date);
  }
  return isSameDay(date, today());
}

export function isToyear(date: Date | string): boolean {
  if (!(date instanceof Date)) {
    date = parseDate(date);
  }
  return isSameYear(date, now());
}

export function compareDates(d1: string, d2: string) {
  if (d1 === d2) {
    return 0;
  }
  if (d1 < d2) {
    return -1;
  }
  return 1;
}

export function minuteDifference(d1: Date, d2: Date): number {
  const minuteDifference = Math.round(
    (d1.getTime() - d2.getTime()) / (1000 * 60),
  );
  return minuteDifference;
}

export function hourDifference(d1: Date, d2: Date): number {
  const hourDifference = Math.round(
    (d1.getTime() - d2.getTime()) / (1000 * 60 * 60),
  );
  return hourDifference;
}

export function dayDifference(d1: Date, d2: Date): number {
  const dayDifference = Math.round(
    (toDate(d1).getTime() - toDate(d2).getTime()) / (1000 * 60 * 60 * 24),
  );
  return dayDifference;
}

export function weekDifference(d1: Date, d2: Date): number {
  const weekDifference = Math.floor(
    (toDate(d1).getTime() - toDate(d2).getTime()) / (1000 * 60 * 60 * 24 * 7),
  );
  return weekDifference;
}

export function yearDifference(d1: Date, d2: Date): number {
  const ageMilis: number = Math.floor(
    toDate(d1).getTime() - toDate(d2).getTime(),
  );
  const yearDifference: number = Math.abs(
    new Date(ageMilis).getUTCFullYear() - 1970,
  );
  return yearDifference;
}

export function parseDate(jsonDate: ?string): ?Date {
  if (
    jsonDate === undefined ||
    jsonDate === null ||
    jsonDate.trim().length === 0
  ) {
    return undefined;
  }
  const date = moment(jsonDate).toDate();
  return date;
}

export function parseTime24Format(time: string): string {
  if (time === undefined || time === null || time.trim().length === 0) {
    return undefined;
  }
  const formattedTime = moment(time, timeFormat).format(time24Format);
  return formattedTime;
}

export function formatDate(date: ?Date | ?string, format: string): string {
  if (
    date === null ||
    date === undefined ||
    date === '' ||
    date.toString().trim() === ''
  ) {
    return '';
  }
  const formattedDate: string = moment(date).format(format);
  if (formattedDate === 'Invalid date') {
    return date;
  }
  return formattedDate;
}

export function formatTime(time: ?string): string {
  if (time === null || time === undefined || time.toString().trim() === '') {
    return '';
  }
  const formattedTime: string = moment(time, time24Format).format('LT');
  if (formattedTime === 'Invalid date') {
    return time;
  }
  return formattedTime;
}

export function formatHour(time: ?string): string {
  if (time === null || time === undefined || time.toString().trim() === '') {
    return '';
  }
  const formattedTime: string = formatTime(time);
  const hour = formattedTime.substring(0, formattedTime.indexOf(':'));
  const suffix: ?string = formattedTime.includes(' ')
    ? formattedTime.substring(formattedTime.indexOf(' '))
    : undefined;
  if (suffix) {
    return hour + suffix;
  }
  return hour;
}

export function formatDuration(
  date: Date | string | number,
  startDate?: Date | string,
): string {
  if (!isNaN(date)) {
    date = new Date(date);
    if (startDate === undefined) {
      startDate = new Date(0);
    } else if (!isNaN(startDate)) {
      startDate = new Date(startDate);
    }
  } else {
    if (!(date instanceof Date)) {
      date = parseDate(date);
    }
  }
  if (!(startDate instanceof Date)) {
    startDate = parseDate(startDate);
  }
  if (date === startDate) {
    return '';
  }
  if (isSameDay(date, startDate)) {
    const minuteCount: number = Math.abs(minuteDifference(date, startDate));
    if (minuteCount === 0) {
      return '';
    }
    if (minuteCount === 1) {
      return '1 ' + strings.minute;
    }
    if (minuteCount === 30) {
      return strings.halfAnHour;
    }
    if (minuteCount === 60) {
      return '1 ' + strings.hour;
    }
    if (minuteCount < 120) {
      return minuteCount + ' ' + strings.minutes;
    }
    const hourCount = Math.abs(hourDifference(date, startDate));
    return hourCount + ' ' + strings.hours; //TODO minutes as decimals?
  }
  const dayCount: number = Math.abs(dayDifference(date, startDate));
  if (dayCount === 1) {
    return '1 ' + strings.day;
  }
  return dayCount + ' ' + strings.days;
}

export function formatAge(date: ?Date | ?string): string {
  if (
    date === undefined ||
    date === null ||
    date.toString().trim().length === 0
  ) {
    return '';
  }
  try {
    if (!(date instanceof Date)) {
      date = parseDate(date);
    }
    const nu = now();
    const age: number = yearDifference(nu, date);
    return age.toString() + ' ' + strings.years;
  } catch (error) {
    console.log(error);
    return '';
  }
}

export function formatMoment(date: Date | string): string {
  if (__DEV__ && !(date instanceof Date) && !isNaN(date)) {
    console.error('Date is a number: ' + date);
  }
  try {
    if (
      date === undefined ||
      date === null ||
      date.toString().trim().length === 0
    ) {
      return '';
    }
    if (!(date instanceof Date)) {
      date = parseDate(date);
    }
    const nu = now();
    if (isSameDay(date, nu)) {
      return formatTime(date);
    }
    const dayCount: number = dayDifference(nu, date);
    if (dayCount < -100) {
      return formatDate(date, farDateFormat);
    }
    if (dayCount < -14) {
      return formatDate(date, dateFormat);
    }
    if (dayCount <= -1) {
      return formatDate(date, dateTime24Format);
    }
    //if (dayCount===-1) return 'Tomorrow '+formatDate(date, time24Format);
    if (dayCount === 0) {
      return formatDate(date, time24Format);
    }
    //if (dayCount===1) return 'Yesterday';
    //if (dayCount <= 14)  return dayCount+' days ago';
    //const weekCount : number = weekDifference(nu, date);
    //if (weekCount <=8) return weekCount+' weeks ago';
    if (dayCount <= 100) {
      return formatDate(date, dateFormat);
    }
    return formatDate(date, farDateFormat);
  } catch (error) {
    console.log(error);
    return '';
  }
}

export function capitalize(text: string): string {
  if (!text || text.length == 0) {
    return text;
  }
  if (text.length === 1) {
    return text.toUpperCase();
  }
  return text.substring(0, 1).toUpperCase() + text.substring(1);
}

export function formatStickySign(number: ?number, decimals: number): string {
  if (number === undefined || number === null) {
    return '';
  }
  if (number < 0) {
    return number.toFixed(decimals);
  }
  return '+' + number.toFixed(decimals);
}
export function formatStickySign2(
  number: number,
  decimals: number,
  prefix: ?string,
  suffix: ?string,
): string {
  if (number === undefined || number === null) {
    return '';
  }
  if (number < 0) {
    return number.toFixed(decimals);
  }
  if (prefix === undefined || prefix === null) {
    prefix = '';
  }
  if (suffix === undefined || suffix === null) {
    suffix = '';
  }

  return prefix + number.toFixed(decimals) + suffix;
}

export function formatDecimals(number: ?number, decimals: number): string {
  if (number === undefined || number === null) {
    return '';
  }
  if (number === 0 || number % 1 === 0) {
    if (decimals === 1) {
      return '.0';
    }
    if (decimals === 2) {
      return '.00';
    }
    if (decimals === 3) {
      return '.000';
    }
    return '.0000';
  }
  let formatted: string = Math.abs(number % 1)
    .toFixed(decimals)
    .substr(1);
  return formatted;
}

export function formatDegree(number: ?number): string {
  if (!number) {
    return '';
  }
  const degreeSymbol: string = '\u{00B0}';
  return number.toString() + degreeSymbol;
}

export function formatDiopter(sph: ?string | ?number) {
  if (isEmpty(sph)) {
    return '';
  }
  if (isFinite(sph)) {
    //'-1.25'|-1.25
    if (Number.isFinite(sph)) {
      //-1.25
      return formatStickySign(sph, 2);
    }
    return formatStickySign(parseFloat(sph), 2);
  } //'balanced'
  return sph;
}

export function deAccent(text: string): string {
  if (text == undefined) {
    return text;
  }
  let accents = {
    à: 'a',
    á: 'a',
    â: 'a',
    ã: 'a',
    ä: 'a',
    ç: 'c',
    è: 'e',
    é: 'e',
    ê: 'e',
    ë: 'e',
    ò: 'o',
    ô: 'o',
    õ: 'o',
    ö: 'o',
  };
  let chars = /[àáâãäçèéêëòôõö]/g;
  return text.replace(chars, (char) => accents[char]);
}

export function isEmpty(value: any): boolean {
  if (value === undefined || value === null) {
    return true;
  }
  if (value === '' || (value.trim !== undefined && value.trim().length === 0)) {
    return true;
  }
  if (value.length === 0) {
    return true;
  }
  if (value instanceof Array) {
    if (value.length === 0) {
      return true;
    } else {
      for (let i: number = 0; i < value.length; i++) {
        if (!isEmpty(value[i])) {
          return false;
        }
      }
      return true;
    }
  } else if (value instanceof Object) {
    if (Object.keys(value).length === 0) {
      return true;
    }
    for (let subValue of Object.values(value)) {
      if (!isEmpty(subValue)) {
        return false;
      }
    }
    return true;
  }
  return false;
}

// remove null and undefined
export function cleanUpArray(a: any[]): any[] {
  return !isEmpty(a) && a instanceof Array
    ? a.filter(function (v) {
        return v !== null && v !== undefined;
      })
    : a;
}

export function deepAssign(
  value: Object,
  newValue: Object,
  appendValue: ?boolean,
): Object {
  for (let [key: string, subNewValue: any] of Object.entries(newValue)) {
    let subValue: any = value[key];

    if (subValue instanceof Array) {
      Array.isArray(subNewValue)
        ? subValue.push(...subNewValue)
        : subValue.push(subNewValue);
    } else if (subValue instanceof Object) {
      if (subNewValue instanceof Array) {
        //ignore setting an array on non array
      } else if (subNewValue instanceof Object) {
        deepAssign(subValue, subNewValue, appendValue);
      } else {
        value[key] = subNewValue;
      }
    } else {
      // subNewValue = appendValue && !isEmpty(subValue) ? subValue.concat(subNewValue) : subNewValue;
      value[key] = subNewValue;
    }
  }
}

export function split(value: ?string, options: string[][]): string[] {
  if (value === undefined) {
    let splittedValue: ?(string[]) = options.map(
      (columnOptions: string[]) => undefined,
    );
    return splittedValue;
  }
  value = value.trim();
  let splittedValue: ?(string[]) = options.map((columnOptions: string[]) => {
    let option: ?string = columnOptions.find(
      (option: string) =>
        value !== undefined &&
        value.toLowerCase().startsWith(option.trim().toLowerCase()),
    );
    if (option !== undefined) {
      value = value.slice(option.trim().length);
      value = value.trim();
    }
    return option;
  });
  if (value.length > 0) {
    if (splittedValue[splittedValue.length - 1] === undefined) {
      splittedValue[splittedValue.length - 1] = value;
    } else {
      splittedValue[splittedValue.length - 1] += value;
    }
  }
  return splittedValue;
}

export function combine(value: string[]): ?string {
  if (value === undefined) {
    return undefined;
  }
  let combinedValue;
  value.forEach((subValue: string) => {
    if (subValue !== undefined) {
      if (combinedValue === undefined) {
        combinedValue = '';
      }
      subValue = subValue.toString();
      combinedValue += subValue;
    }
  });
  if (combinedValue !== undefined) {
    combinedValue = combinedValue.trim();
  }
  return combinedValue;
}

export function passesFilter(value: Object, filter: {}): boolean {
  if (filter === undefined) {
    return true;
  }
  const filterEntries: [][] = Object.entries(filter);
  for (let i: number = 0; i < filterEntries.length; i++) {
    const filterKey: string = filterEntries[i][0];
    const filterValue: string = filterEntries[i][1];
    if (
      filterKey !== undefined &&
      filterValue !== undefined &&
      filterValue.trim() !== ''
    ) {
      const subValue = value[filterKey];
      const passesFilter: boolean =
        typeof subValue === 'string'
          ? subValue.trim().toLowerCase() === filterValue.trim().toLowerCase()
          : subValue === filterValue;
      if (!passesFilter) {
        return false;
      }
    }
  }
  return true;
}

export function stripIndex(identifier: string): string {
  if (identifier.endsWith(']')) {
    identifier = identifier.substring(0, identifier.indexOf('['));
  }
  return identifier;
}

function getIndex(identifier: string): ?number {
  if (identifier.endsWith(']')) {
    let index = identifier.substring(
      identifier.indexOf('[') + 1,
      identifier.indexOf(']'),
    );
    return parseInt(index);
  }
  return undefined;
}

function subValue(value, identifier: string) {
  if (value === undefined || value === null) {
    return value;
  }
  let subValue = value[stripIndex(identifier)];
  const index: ?number = getIndex(identifier);
  if (index !== undefined) {
    subValue = subValue[index];
  } else if (value instanceof Array) {
    for (const subElement: any of value) {
      subValue = subElement[stripIndex(identifier)];
      if (!isEmpty(subValue)) {
        break;
      }
    }
  }
  return subValue;
}

export function getValue(value, fieldIdentifier: string) {
  let identifiers: string[] = fieldIdentifier.split('.');
  for (const identifier: string of identifiers) {
    value = subValue(value, identifier);
  }
  return value;
}

export function setValue(value: {}, fieldIdentifier: string, fieldValue: any) {
  let identifiers: string[] = fieldIdentifier.split('.');
  for (let i = 0; i < identifiers.length - 1; i++) {
    const identifier: string = identifiers[i];
    let childValue = subValue(value, identifier);
    if (childValue === undefined) {
      if (value === undefined) {
        return;
      }
      childValue = {};
      value[identifier] = childValue;
    }
    value = childValue;
  }
  const identifier: string = identifiers[identifiers.length - 1];
  value[identifier] = fieldValue;
}

export function replaceFileExtension(
  fileName: string,
  extension: string,
): string {
  if (
    fileName === null ||
    fileName === undefined ||
    extension === null ||
    extension === undefined
  ) {
    return fileName;
  }
  const dotIndex: number = fileName.lastIndexOf('.');
  if (dotIndex <= 0) {
    return fileName;
  }
  if (extension.startsWith('.')) {
    extension = extension.substring(1);
  }
  fileName = fileName.substring(0, dotIndex + 1) + extension;
  return fileName;
}

export function prefix(text: ?string, prefix: string): string {
  if (isEmpty(text)) {
    return '';
  }
  if (isEmpty(prefix)) {
    return text;
  }
  return prefix + text;
}

export function postfix(text: ?string, postfix: string): string {
  if (isEmpty(text)) {
    return '';
  }
  return '' + text + postfix;
}

export function sort(array: []): [] {
  return array.sort((a, b) => a - b);
}

export function insertNewlines(text: string): string {
  if (text === undefined || text === null) {
    return text;
  }
  text = text.replace(/  +/g, '\n');
  return text;
}

export function extractHostname(url) {
  let hostname;
  //find & remove protocol (http, ftp, etc.) and get hostname
  if (url.indexOf('//') > -1) {
    hostname = url.split('/')[2];
  } else {
    hostname = url.split('/')[0];
  }
  //find & remove port number
  hostname = hostname.split(':')[0];
  //find & remove "?"
  hostname = hostname.split('?')[0];

  return hostname;
}

export function getRanges(
  minValue: number,
  maxValue: number,
  interval: number,
): number[] {
  let tempArray: number[] = [];
  for (let i = minValue; i <= maxValue; i += Math.abs(interval)) {
    tempArray.push(Math.round((i + Number.EPSILON) * 100) / 100);
  }
  if (!tempArray.includes(maxValue)) {
    tempArray.push(maxValue);
  }

  return tempArray;
}

export function formatRanges(
  ranges: number[],
  decimals: number,
  prefix?: string,
  suffix?: string | string[],
): string[] {
  let finalRangeArray: string[] = [];

  ranges.map((n: number) => {
    if (suffix && suffix instanceof Array) {
      finalRangeArray.push(formatStickySign2(n, decimals, prefix, ''));
      suffix.map((subElement: string) => {
        const value: string = formatStickySign2(
          n,
          decimals,
          prefix,
          subElement,
        );
        finalRangeArray.push(value);
      });
    } else {
      const value: string = formatStickySign2(n, decimals, prefix, suffix);
      finalRangeArray.push(value);
    }
  });
  return finalRangeArray;
}

export function passesRangeFilter(value: Object, filter: {}): boolean {
  if (filter === undefined) {
    return true;
  }
  const filterEntries: [][] = Object.entries(filter);
  for (let i: number = 0; i < filterEntries.length; i++) {
    const filterKey: string = filterEntries[i][0];
    const filterValue: string = filterEntries[i][1];
    if (filterKey !== undefined && filterValue !== undefined) {
      const subValue = value[filterKey];
      if (subValue instanceof Object) {
        const filterValueNumber: number = parseFloat(filterValue);
        let modulo: number = Math.abs(
          (filterValueNumber - subValue.minValue) % subValue.stepSize,
        );
        modulo = Math.round((modulo + Number.EPSILON) * 100) / 100;

        if (
          filterValueNumber < subValue.minValue ||
          filterValueNumber > subValue.maxValue ||
          modulo > 0.1 ||
          (modulo !== 0 && modulo < 0.1 && subValue.stepSize <= 0.1)
        ) {
          return false;
        }
      }
    }
  }
  return true;
}

export function deepEqual(object1: any, object2: any) {
  if (object1 === undefined && object2 === undefined) {
    return true;
  }
  const keys1 = Object.keys(object1);
  const keys2 = Object.keys(object2);
  if (keys1.length !== keys2.length) {
    return false;
  }
  for (const key of keys1) {
    const val1 = object1[key];
    const val2 = object2[key];
    const areObjects = isObject(val1) && isObject(val2);
    if (
      (areObjects && !deepEqual(val1, val2)) ||
      (!areObjects && val1 !== val2)
    ) {
      return false;
    }
  }
  return true;
}
function isObject(object: any) {
  return object != null && typeof object === 'object';
}

export function sleep(milliseconds: number) {
  return new Promise((resolve) => {
    setTimeout(resolve, milliseconds);
  });
}

export function getDoctorFullName(doctor: User): string {
  if (doctor) {
    return `${doctor.firstName && doctor.firstName.trim()} ${
      doctor.lastName && doctor.lastName.trim()
    }`;
  } else {
    return '';
  }
}

export function getCurrentRoute(navigationState) {
  if (!navigationState) {
    return null;
  }
  const route = navigationState.routes[navigationState.index];
  // dive into nested navigators
  if (route.routes) {
    return getCurrentRoute(route);
  }
  return route;
}

export function parseImageURL(image : String): String {
  if(typeof image === "string" || image instanceof String){
    const templateURL = "https://attachment.downloadwink.com/WinkRESTvWinkWeb/";
    if (image.startsWith(templateURL)) {
      let restUrl = isWeb ? process.env.WINK_APP_REST_URL : WINK_APP_REST_URL;
      if(!restUrl.endsWith('/')){
        restUrl += '/';
      }
      image = restUrl + image.substring(templateURL.length);
    }

    try {
      if (image.startsWith("./image")) {
          const envImageBaseURL = isWeb ? process.env.WINK_IMAGE_URL : WINK_IMAGE_URL;
          image = image.replace("./image",envImageBaseURL);
      }
    } catch (ex) {
      __DEV__ & console.log("Environment WINK_IMAGE_URL missing");
    }
  }
  return image;
}
/**
 * @flow
 */
'use strict';

export type RestResponse = {
  patient?: PatientInfo,
  exam?: Exam,
  errors?: string[],
  hasValidationError?: boolean,
  hasConcurrencyConflict?: boolean,
};

export type Registration = {
  email: string,
  bundle: string,
  path: string,
};

export type AgentAssumption = {
  zendeskRef: string,
  reason: string,
};

export type VisitType = {
  id: string,
  name: string,
  nameEn: string,
  nameFr: string,
  nameEs: string,
  digital: boolean,
  inactive: boolean,
  version: number,
  examDefinitionIds: string[],
  doctorIds: string[],
};

export type PatientInvoice = {
  id: string,
  invoiceNumber: string,
  invoiceDate?: string,
};

export type Store = {
  id: string,
  storeId: number, //TODO Chris
  name: string,
  companyName: string,
  streetNumber: string,
  unit: string,
  streetName: string,
  city: string,
  country: number,
  pr: string,
  postalCode: string,
  email: string,
  telephone: string,
  winkToWinkId?: number,
  winkToWinkEmail?: string,
  eFaxUsed?: boolean,
  fax?: string,
  defaultMedicationRxNote?: string,
  website?: string,
  displayLogoWithRx?: boolean,
};

export type Account = {
  id: number,
  name: string,
  email: string,
  stores: Store[],
  isDemo: boolean,
  extraFields: any,
};

export type User = {
  id: string,
  version: number,
  firstName?: string,
  lastName?: string,
  instituteName?: string,
  license?: string,
  signatureId?: string,
  email?: string,
  fax?: string,
  tel1?: string,
  tel2?: string,
  adress1?: string,
  adress2?: string,
  province?: string,
  postalcode?: string,
  city?: string,
  isExternal: boolean,
  providerType?: string,
  username?: string,
  country?: string,
  countryId?: number,
};

export type Privilege = 'NOACCESS' | 'READONLY' | 'BOOKONLY' | 'FULLACCESS';

export type Privileges = {
  pretestPrivilege?: Privilege,
  medicalDataPrivilege?: Privilege,
  appointmentPrivilege?: Privilege,
  referralPrivilege?: Privilege,
  finalRxPrivilege?: Privilege,
  fittingPrivilege?: Privilege,
  patientPrivilege?: Privilege,
};

export type TokenPrivilege = 'N' | 'R' | 'B' | 'F';

export const PRIVILEGE = {
  FULLACCESS: 'FULLACCESS',
  NOACCESS: 'NOACCESS',
  READONLY: 'READONLY',
};

export type TokenPrivileges = {
  pre: ?TokenPrivilege,
  med: ?TokenPrivilege,
  app: ?TokenPrivilege,
  ref: ?TokenPrivilege,
  fin: ?TokenPrivilege,
  fit: ?TokenPrivilege,
  pat: ?TokenPrivilege,
};

export type TokenPayload = {
  sub: string,
  exp: number,
  prv: TokenPrivileges,
};

export type Patient = {
  id: string,
  firstName: string,
  lastName: string,
  alias: string,
  phone: ?string,
  cell: ?string,
  patientTags: string[],
};

export type PatientInfo = {
  id: string,
  version: number,
  errors?: string[],
  firstName: string,
  lastName: string,
  alias: string,
  dateOfBirth: string,
  gender: number,
  phone: ?string,
  cell: ?string,
  streetName: string,
  countryId: number,
  medicalCard: string,
  medicalCardExp: string,
  medicalCardVersion: string,
  postalCode: string,
  email: string,
  province: string,
  country: string,
  gender: number,
  streetNumber: string,
  unit: string,
  patientTags: string[],
  patientDrugs: string[], //TODO wais rename patientDrugIds
  familyDoctorId: ?number,
  familyDoctor: ?User,
  occupation?: string,
};

export type PatientDrug = {
  id: string,
  patientId: string,
  userId: string, //TODO Wais rename prescriberId
  visitId: string,
  datePrescribed: string,
  dose: number,
  doseUnit: number,
  repeat: number,
  duration: string,
  note: string,
  noaccess?: boolean,
};

export type Prescription = {
  label?: string,
  strength?: string,
  dosage?: string,
  frequency?: string,
  duration?: string,
  instructions?: string,
  refill?: string,
  doNotSubstitute?: string,
  comment?: string,
  rxDate?: string,
  noaccess?: boolean,
  readonly?: boolean,
};

export type PatientTag = {
  id: string,
  letter: string,
  color: string,
  name: string,
  version: number,
};

export type AppointmentType = {
  id: string,
  color: string,
  name: string,
  version: number,
};

export type Appointment = {
  id: string,
  version: number,
  patientId: string,
  userId: string,
  title: string,
  start: string | Date,
  end: string | Date,
  status: number,
  appointmentTypes?: string[],
  indicators?: string[],
  comment?: string,
  supplierId?: string,
  isBusy?: boolean,
  earlyRequest?: boolean,
  earlyRequestComment?: string,
  numberOfSlots?: number,
  appointmentPrivilege?: Privilege,
  inactive?: boolean,
  supplier?: Supplier,
};

export type Supplier = {
  id: string,
  name: string,
};

export type Prism = {
  prismH?: number,
  prismHDirection?: string,
  prismV?: number,
  prismVDirection?: string,
};

export type GlassRx = {
  sph?: string,
  cyl?: number,
  axis?: number,
  prism?: string,
  add?: number,
  va?: string,
  addVA?: string,
  isEye?: boolean,
  closePD?: number,
  farPD?: number,
  bvd?: string,
};

export type GlassesRx = {
  od: GlassRx,
  os: GlassRx,
  ou: GlassRx,
  expiry?: string,
  prescriptionDate?: string,
  signedDate?: string,
  vaFar?: string,
  vaNear?: string,
  lensType?: string,
  customField?: string,
  notes?: string,
  doctor?: string,
  readonly?: boolean,
  noaccess?: boolean,
  testingCondition?: string,
  currentWear?: string,
  since?: string,
};

export type Recall = {
  amount: number,
  unit: string,
  notes: string,
};

export type ImageDrawing = {
  lines: string[],
  image?: string, //"upload-123" | "./image/amsler.png" | "http://anywhere.com/image.png",
};

export type Measurement = {
  label: string,
  date?: string,
  patientId?: string,
  machineId?: string,
  data: any,
};

export type Configuration = {
  machine: {phoropter: string},
};

export type Visit = {
  id: string,
  version: number,
  appointmentId?: string,
  patientId: string,
  userId?: string,
  enteredByUserId?: string,
  preCustomExamIds: string[],
  customExamIds: string[],
  date: string,
  duration: number,
  locked: boolean,
  typeName: string,
  visitTypeId?: string,
  isDigital: boolean,
  storeId?: string,
  prescription: GlassesRx,
  recall: Recall,
  purchase: {add: number, comment: string, purchaseReasonId: string}[],
  inactive: boolean,
  pretestPrivilege?: Privilege,
  medicalDataPrivilege?: Privilege,
  finalRxPrivilege?: Privilege,
  fittingPrivilege?: Privilege,
  consultationDetail?: ConsultationDetail,
  invoices?: PatientInvoice[],
};

export type ConsultationDetail = {
  lastUpdateOn?: string,
  lastUpdateBy?: string,
  lockedOn?: string,
  pretestPrivilege?: Privilege,
  medicalDataPrivilege?: Privilege,
  enteredByUserId?: string,
};

export type CodeDefinition =
  | {
      code: string | number,
      description?: string,
      key?: string, //this is a reference to the Strings.js constants
      readonly?: boolean,
    }
  | string;

export type FieldLayout = {
  top: number,
  left: number,
  width: number,
  height: number,
};

export type Dimension = {
  width: number,
  height: number,
};

export type GraphDefinition = {
  fields: string[],
};

export type FieldDefinition = {
  name: string,
  label?: string,
  multiValue?: boolean, //Can contain more then 1 value
  options?: CodeDefinition[][] | CodeDefinition[] | string,
  autoSelect?: boolean, //Overwrite user selection when filtered options change
  popularOptions?: CodeDefinition[],
  filter?: {},
  defaultValue?: boolean | string | number,
  normalValue?: string,
  freestyle?: boolean, //Allow keyboard input when there are fe options, stepsize, date type
  required?: boolean,
  requiredError?: string,
  readonly?: boolean,
  minValue?: number,
  maxValue?: number,
  stepSize?: number,
  groupSize?: number,
  decimals?: number,
  minLength?: number,
  minLengthError?: string,
  maxLength?: number,
  maxLengthError?: string,
  prefix?: string | string[],
  suffix?: string,
  validation?: string,
  mappedField?: string,
  layout?: FieldLayout,
  size?: string,
  resolution?: string,
  type?:
    | 'email-address'
    | 'numeric'
    | 'phone'
    | 'pastDate'
    | 'recentDate'
    | 'partialPastDate'
    | 'futureDate'
    | 'futureDateTime'
    | 'time'
    | 'pastTime'
    | 'futureTime',
  capitalize?: 'words' | 'characters' | 'sentences' | 'none',
  image?: string,
  simpleSelect?: boolean,
  newLine?: boolean,
  popup?: boolean,
  drawable?: boolean,
  sync?: boolean,
  visible?: boolean,
  isLabel?: boolean,
  limitedValues?: {},
  forceSync?: boolean,
  listField?: boolean,
  rangeFilter?: {},
  hasRange?: boolean,
  selectedIndex?: number, //sets default index option when autoSelect is true
  highlightedLabel?: boolean,
  highlightedValue?: boolean,
  delimiter?: string,
  maxRows?: number,
  showTextInfoTip?: boolean,
  unit?: string,
  prefixStyle?: PrefixStyle,
};

export type FieldDefinitions = (FieldDefinition | GroupDefinition)[];

export type GroupDefinition = {
  name: string,
  label?: string,
  size?: string, //XS S M L XL
  optional?: boolean,
  columns?: string[][],
  rows?: string[][],
  multiValue?: boolean,
  readonly?: boolean,
  options?: CodeDefinition[][] | CodeDefinition[] | string,
  maxLength?: number,
  mappedField?: string,
  canBeCopied?: boolean,
  canBePaste?: boolean,
  keyboardEnabled?: boolean,
  clone?: string[],
  hasVA?: boolean,
  hasAdd?: boolean,
  hasLensType?: boolean,
  hasPD?: boolean,
  hasMPD?: boolean,
  hasNotes?: boolean,
  hasCustomField?: boolean,
  import?: string | string[],
  export?: string | string[],
  fields: (FieldDefinition | GroupDefinition)[],
  copyToFinalRx?: boolean,
  showSubtitles?: boolean,
  hasBVD?: boolean,
  starable?: boolean,
  maxRows?: number,
  showTextInfoTip?: boolean,
  importFirstIndexOnly?: boolean,
  hasCurrentWear?: boolean,
};

export type HtmlDefinition = {
  name: string,
  html: string,
  child?: HtmlDefinition | HtmlDefinition[],
};

export type ImageBase64Definition = {
  key: string,
  value: string,
};

export type ReferralDocument = {
  content: string,
  builtInTemplates?: any,
};

export type ReferralDefinition = {
  id: string,
  visitId: string,
  fromDoctorId: string,
  upload?: Upload,
};

export type FollowUp = {
  id: string,
  ref: string,
  linkedReferralId: string,
  visitId?: string,
  patientInfo: PatientInfo,
  storeId: string,
  referralTemplate: ReferralTemplate,
  date: string,
  from: User,
  to: User,
  faxedOn?: string,
  emailOn?: string,
  printedOn?: string,
  signedOn?: string,
  status?: string,
  comment?: string,
  isOutgoing?: boolean,
  isParent?: boolean,
  referralPrivilege?: Privilege,
};

export type ReferralStatusCode = {
  code: string,
  description: string,
  status: string,
};
export type ReferralTemplate = {
  id: string,
  template: string,
};

export type EmailDefinition = {
  to?: string,
  cc?: string,
  subject?: string,
  body?: string,
  builtInTemplate?: any,
};

export type ExamDefinition = {
  id: string,
  version: number,
  name: string,
  label?: string,
  fields?: (FieldDefinition | GroupDefinition)[],
  type: string, //GroupedForm || SelectionLists
  card?: boolean,
  cardFields?: string[] | string[][],
  cardGroup?: string,
  essentialFields: string[],
  titleFields: string[],
  editable: boolean,
  addable: boolean,
  isPreExam: boolean,
  isAssessment: boolean,
  image?: string,
  graph?: GraphDefinition,
  section: string, //History.3
  order?: string, //order used for pre tests
  starable?: boolean,
  relatedExams?: string[],
  scrollable?: boolean,
  layout?: any,
  signable?: boolean,
  showSubtitles?: boolean,
  multiValue?: boolean, //Can Add more than 1 exam,
  addablePostLock?: boolean,
  export?: string | string[],
  isPatientFileHidden?: boolean,
  isInactive: boolean,
  appendStarValues?: boolean,
  permanentRelatedExams?: string[],
};

export type ExamPredefinedValue = {
  id: string,
  version: number,
  customExamDefinitionId: string, //TODO: wais
  name: string,
  predefinedValue: any,
  userId?: string,
  order?: number,
};

export type Exam = {
  id: string,
  visitId: string,
  version: number,
  errors?: string[],
  definition: ExamDefinition,
  hasStarted: boolean,
  isDirty?: boolean,
  isInvalid?: boolean,
  isHidden?: boolean,
  readonly?: boolean,
  noaccess?: boolean,
  next?: string,
  previous?: string,
  visitDate?: string,
};

export type Scene = {
  key: string,
  scene: string,
  menuHidden?: boolean,
  nextNavigation?: any,
  appointment?: Appointment,
  patient?: Patient,
  patientInfo?: PatientInfo,
  exam?: Exam,
  examDefinition?: ExamDefinition,
};

export type Upload = {
  id: string,
  data: string, //base64 encoded for binary data
  name: string,
  date?: string,
  mimeType: string,
  argument1?: string,
  argument2?: string,
};

export type PatientDocument = {
  id: string,
  patientId: string,
  postedOn: string,
  name: string,
  category: string,
  uploadId: string,
};

export type TranslationDefinition = {
  id: string,
  fieldId: string,
  language: string,
  label: ?string,
  normalValue: ?string,
};

export type ExamRoom = {
  id: string,
  patientId: string,
  examRoomId: string,
  name: string,
};

export type VisitSummary = {
  visitId: string,
  refraction: ?GlassesRx,
  summary: ?(Exam[]),
  billing: ?(Exam[]),
  medications: ?(Prescription[]),
  fieldDefinitions: ?(FieldDefinition[]),
  noaccess: ?boolean,
  visit: ?Visit,
};

export type EmrHost = {
  host: string,
  path: string,
  version: string,
};

export type KeyCommand = {
  input: string,
  modifierFlags: string,
  discoverabilityTitle: string,
};

export type PrefixStyle = {
  color?: string, 
  fontSize?: number, 
  height?: number, 
  paddingTop?: number, 
  paddingBottom?: number, 
  paddingLeft?: number,
  paddingRight?: number, 
  margin?: number
};

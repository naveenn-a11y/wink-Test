/**
 * @flow
 */
'use strict';

import { Component } from 'react';
import {
  Button,
  ScrollView,
  Text,
  TouchableHighlight,
  TouchableOpacity,
  View,
} from 'react-native';
import { formatAllCodes, formatCode, parseCode } from './Codes';
import { cacheItem, getCachedItem } from './DataCache';
import { getExamDefinition } from './ExamDefinition';
import {
  Favorites,
  Garbage,
} from './Favorites';
import { FormRow, FormTextInput } from './Form';
import { GroupedForm } from './GroupedForm';
import {
  formatPrism,
} from './Refraction';
import { fetchItemDefinition, getDefinitionCacheKey } from './Rest';
import { strings } from './Strings';
import { fontScale, isWeb, selectionColor, styles } from './Styles';
import type {
  Exam,
  ExamDefinition,
  ExamPredefinedValue,
  FieldDefinition,
  FieldDefinitions,
  GroupDefinition,
  Prescription,
} from './Types';
import {
  dateFormat,
  deepClone,
  formatDate,
  formatTime,
  isEmpty,
  isToyear,
  yearDateFormat,
} from './Util';
import {
  Label,
  NoAccess,
  SelectionList,
  selectionPrefix,
  stripSelectionPrefix,
} from './Widgets';

export function getFieldDefinitions(itemId: string): ?FieldDefinitions {
  if (itemId === undefined || itemId === null) {
    return null;
  }
  const cacheKey: string = getDefinitionCacheKey(itemId);
  let definitions: FieldDefinitions = getCachedItem(cacheKey);
  return definitions;
}

export function filterFieldDefinition(
  fieldDefinitions: ?(FieldDefinition[]),
  fieldNames: string[] | string,
  startIndex: number = 0,
): ?FieldDefinition {
  if (!fieldDefinitions) {
    __DEV__ && console.error('Filtering empty fieldDefinitions');
    return undefined;
  }
  if (!Array.isArray(fieldNames)) {
    fieldNames = fieldNames.split('.');
  }
  let fieldDefinition: ?FieldDefinition | ?GroupDefinition;
  for (let i = startIndex; i < fieldNames.length; i++) {
    fieldDefinition = fieldDefinitions.find(
      (fieldDefinition: FieldDefinition | GroupDefinition) =>
        fieldDefinition.name === fieldNames[i],
    );
    if (fieldDefinition && fieldDefinition.fields !== undefined) {
      fieldDefinitions = fieldDefinition.fields;
    }
  }
  if (fieldDefinition === undefined) {
    __DEV__ && console.error("No fieldDefinition '" + fieldNames + "' exists.");
    return undefined;
  }
  return fieldDefinition;
}

export function getFieldDefinition(fullFieldName: string): ?FieldDefinition {
  let fieldNames: string[] = fullFieldName.split('.');
  if (fieldNames === undefined || fieldNames.length < 2) {
    return undefined;
  }
  if (fieldNames[0] === 'clFitting') {
    return undefined;
  }
  let fieldDefinitions: ?(FieldDefinition[]);
  if (fieldNames[0] === 'exam' && fieldNames.length > 1) {
    fieldDefinitions = getExamDefinition(fieldNames[1]).fields;
    fieldNames.splice(0, 1);
  } else {
    fieldDefinitions = getFieldDefinitions(fieldNames[0]);
  }
  if (fieldDefinitions === undefined) {
    //__DEV__ && console.warn('No fieldDefinitions exists for '+fieldNames[0]);
    return undefined;
  }
  return filterFieldDefinition(fieldDefinitions, fieldNames, 1);
}

export async function cacheDefinitions(language: string) {
  cacheItem('preExamDefinitions', undefined);
  cacheItem('assessmentDefinitions', undefined);
  cacheItem('examDefinitions', undefined);
  cacheItem('examPredefinedValues', undefined);
  cacheItem('visitTypes', undefined);
  await fetchItemDefinition('patient', language);
  await fetchItemDefinition('visit', language);
  await fetchItemDefinition('user', language);
}

export function formatValue(
  value: ?string | ?number | ?(string[]) | ?(number[]),
  fieldDefinition: FieldDefinition,
): string {
  if (value === undefined || value === null || value === '') {
    return '';
  }
  if (typeof value === 'string') {
    let formattedValue = value;
    if (
      fieldDefinition.prefix === '+' &&
      !formattedValue.startsWith('-') &&
      !formattedValue.startsWith('+')
    ) {
      formattedValue = '+' + formattedValue;
    }
    return formattedValue;
  } else if (typeof value === 'number') {
    let decimals: ?number = fieldDefinition.decimals;
    let formattedValue: string =
      decimals === undefined || decimals === null || decimals < 0
        ? value.toString()
        : value.toFixed(decimals);
    if (
      fieldDefinition.prefix === '+' &&
      !formattedValue.startsWith('-') &&
      !formattedValue.startsWith('+')
    ) {
      formattedValue = '+' + formattedValue;
    }
    return formattedValue;
  } else {
    return new String(value).valueOf();
  }
}

export function formatFieldValue(value, fieldDefinition) {
  if (!fieldDefinition) return '';

  value = value ?? fieldDefinition.defaultValue;
  if (value == null || value === '') return '';

  if (isCheckboxField(fieldDefinition)) {
    return formatCheckboxValue(value, fieldDefinition);
  }

  if (isDateField(fieldDefinition)) {
    return formatDateValue(value, fieldDefinition);
  }

  if (isTimeField(fieldDefinition)) {
    return formatTimeValue(value, fieldDefinition);
  }

  if (isPrismField(fieldDefinition)) {
    return formatPrism(value);
  }

  if (isCodeField(fieldDefinition)) {
    return formatCodeValue(value, fieldDefinition);
  }

  return formatGenericValue(value, fieldDefinition);
}

function isCheckboxField(fieldDefinition) {
  return (
    fieldDefinition.options?.length === 2 &&
    fieldDefinition.defaultValue === fieldDefinition.options[0]
  );
}

function formatCheckboxValue(value, fieldDefinition) {
  const label = formatLabel(fieldDefinition);
  if (value === true) return label;
  if (value === false || value === fieldDefinition.defaultValue) return '';

  return formatGenericValue(value, fieldDefinition);
}

function isDateField(fieldDefinition) {
  return fieldDefinition.type?.includes('Date') ?? false;
}

function formatDateValue(value, fieldDefinition) {
  const formattedDate = formatDate(value, isToyear(value) ? dateFormat : yearDateFormat);
  if (hasPrefixOrSuffix(fieldDefinition)) {
    return formatWithPrefixAndSuffix(
      formatPrefix(fieldDefinition, value),
      formattedDate,
      formatSuffix(fieldDefinition),
    );
  }

  return formattedDate;
}

function isTimeField(fieldDefinition) {
  return fieldDefinition.type === 'time' || (typeof fieldDefinition.type === 'string' && fieldDefinition.type.includes('Time'));
}

function formatTimeValue(value, fieldDefinition) {
  const formattedTime = formatTime(value);
  if (hasPrefixOrSuffix(fieldDefinition)) {
    return formatWithPrefixAndSuffix(
      formatPrefix(fieldDefinition, value),
      formattedTime,
      formatSuffix(fieldDefinition),
    );
  }

  return formattedTime;
}

function isPrismField(fieldDefinition) {
  return fieldDefinition.type === 'prism';
}

function isCodeField(fieldDefinition) {
  return (
    fieldDefinition.options &&
    !fieldDefinition.combineOptions &&
    !(fieldDefinition.options instanceof Array)
  );
}

function formatCodeValue(value, fieldDefinition) {
  const codeType = fieldDefinition.options;

  if (fieldDefinition.multiValue) {
    if (!Array.isArray(value) || value.length === 0) return '';
    return value.map((code, index) => {
      const spacing = index !== 0 ? ' ' : '';
      const prefix = selectionPrefix(code);
      const suffix = formatSuffix(fieldDefinition);
      return `${spacing}${formatWithPrefixAndSuffix(prefix, formatCode(codeType, stripSelectionPrefix(code)), suffix)}`;
    }).join('');
  }

  const prefix = selectionPrefix(value);
  const suffix = formatSuffix(fieldDefinition);
  const formattedValue = fieldDefinition.decimals && fieldDefinition.decimals > 0
    ? Number(value).toFixed(fieldDefinition.decimals)
    : value;

  return formatWithPrefixAndSuffix(prefix, formatCode(codeType, stripSelectionPrefix(formattedValue)), suffix);
}

function formatGenericValue(value, fieldDefinition) {
  const formattedValue = formatValue(value, fieldDefinition);
  if (hasPrefixOrSuffix(fieldDefinition)) {
    return formatWithPrefixAndSuffix(
      formatPrefix(fieldDefinition, value),
      formattedValue,
      formatSuffix(fieldDefinition),
    );
  }
  return formattedValue;
}

function hasPrefixOrSuffix(fieldDefinition) {
  return (
    (fieldDefinition.prefix && !(fieldDefinition.prefix instanceof Array)) ||
    (fieldDefinition.suffix && !(fieldDefinition.suffix instanceof Array))
  );
}

function formatWithPrefixAndSuffix(prefix, value, suffix) {
  // If value is empty, return an empty string
  if (!value) return '';

  // If both prefix and suffix are null or undefined, return the value as is
  if (prefix == null && suffix == null) return value;

  let result = value;
  // Check if the value already contains the prefix
  const startsWithPrefix = prefix && value.startsWith(prefix);
  // Check if the value already contains the suffix
  const endsWithSuffix = suffix && value.endsWith(suffix);
  // Prepend the prefix if it's defined and not already present
  if (prefix && !startsWithPrefix) {
    result = prefix + result;
  }
  // Append the suffix if it's defined and not already present
  if (suffix && !endsWithSuffix) {
    result = result + suffix;
  }

  return result;
}

export function isNumericField(fieldDefinition: FieldDefinition): boolean {
  return (
    fieldDefinition.minValue !== undefined ||
    fieldDefinition.maxValue !== undefined
  );
}

export function formatFieldLabel(
  groupDefinition: GroupDefinition,
  groupValue: any,
  defaultLabel: ?string,
): string {
  const customDefinition: ?GroupDefinition | FieldDefinition =
    groupDefinition.fields
      ? groupDefinition.fields.find(
          (definition: GroupDefinition | FieldDefinition) =>
            definition.isLabel === true,
        )
      : undefined;

  let label: string = isEmpty(defaultLabel)
    ? formatLabel(groupDefinition)
    : defaultLabel;
  if (customDefinition) {
    if (groupValue[customDefinition.name] instanceof Object) {
      label = !isEmpty(groupValue[customDefinition.name].label)
        ? groupValue[customDefinition.name].label
        : label;
    } else {
      label = !isEmpty(groupValue[customDefinition.name])
        ? groupValue[customDefinition.name]
        : label;
    }
  }

  return label;
}

export function formatLabel(
  fieldDefinition:
    | FieldDefinition
    | GroupDefinition
    | {name: string, label: ?string},
): string {
  if (fieldDefinition === undefined) { 
    return '';
  }
  if (fieldDefinition.label !== undefined && fieldDefinition.label !== null) {
    return fieldDefinition.label;
  }
  return fieldDefinition.name;
}

export function formatSuffix(
  fieldDefinition: FieldDefinition | GroupDefinition,
): string {
  if (
    fieldDefinition === undefined ||
    fieldDefinition.suffix === undefined ||
    fieldDefinition.suffix instanceof Array ||
    fieldDefinition.suffix.includes('Code')
  ) {
    return '';
  }
  return fieldDefinition.suffix;
}

export function formatPrefix(
  fieldDefinition: FieldDefinition | GroupDefinition,
  value: any,
): string {
  if (fieldDefinition === undefined || fieldDefinition.prefix === undefined) {
    return '';
  }
  if (
    fieldDefinition.options instanceof Array &&
    fieldDefinition.options.includes(value)
  ) {
    return '';
  }
  if (fieldDefinition.prefix === '+') {
    return '';
  }
  if (value && value.startsWith && value.startsWith(fieldDefinition.prefix)) {
    return '';
  }
  if (
    fieldDefinition.minValue != undefined &&
    fieldDefinition.maxValue != undefined
  ) {
    //TODO: This is copy paste form NumberField in Widgets.js !
    if (isNaN(value)) {
      if (fieldDefinition.prefix != '+') {
        let formattedValue: string = value.toString();
        let freeType: boolean = false;
        for (let i = 0; i < formattedValue.length; i++) {
          const character: char = formattedValue.charAt(i);
          if ('0123456789.-+'.includes(character) === false) {
            freeType = true;
            break;
          }
        }
        if (freeType) {
          return '';
        }
      }
    }
  }
  return fieldDefinition.prefix;
}

function constructItemView(
  itemView: string,
  item: any,
  fieldDefinitions: FieldDefinition[],
  isSelected: boolean,
  editable: boolean,
  onUpdateItem?: (propertyName: string, value: any) => void,
  orientation: string,
  titleFields?: string[],
  showLabels: boolean = false,
) {
  switch (itemView) {
    case 'EditableItem':
      return (
        <View style={{flex: 10}}>
          <EditableItem
            item={item}
            fieldDefinitions={fieldDefinitions}
            titleFields={titleFields}
            isSelected={isSelected}
            onUpdateItem={onUpdateItem}
            orientation={orientation}
            editable={editable}
          />
        </View>
      );
  }
  return (
    <View style={isSelected ? styles.listRowSelected : styles.listRow}>
      <ItemSummary
        item={item}
        orientation={orientation}
        fieldDefinitions={fieldDefinitions}
        editable={editable}
        showLabels={showLabels}
        titleFields={titleFields}
      />
    </View>
  );
}

type ItemSummaryProps = {
  item: any,
  fieldDefinitions: ?(FieldDefinition[]),
  editable?: boolean,
  orientation?: string,
  showLabels?: boolean,
  titleFields?: string[],
};
export class ItemSummary extends Component<ItemSummaryProps> {
  render() {
    if (!this.props.item || !this.props.fieldDefinitions) {
      return null;
    }
    if (this.props.item?.noaccess) {
      const itemKeys = Object.keys(this.props.item);
      let formattedValue: string = '';
      this.props.titleFields &&
        this.props.titleFields.forEach((fieldName: string) => {
          if (itemKeys.indexOf(fieldName) !== -1) {
            let fieldValue = this.props.item[fieldName];
            if (!isEmpty(fieldValue)) {
              let fieldDefinition: ?FieldDefinition =
                this.props.fieldDefinitions.find(
                  (fieldDefinition) => fieldDefinition.name === fieldName,
                );
              if (fieldDefinition === undefined || fieldDefinition === null) {
                if (fieldDefinition.label) {
                  fieldDefinition = this.props.fieldDefinitions.find(
                    (fieldDefinition) => fieldDefinition.label === fieldName,
                  );
                }
              }
              if (fieldDefinition) {
                formattedValue +=
                  formatFieldValue(fieldValue, fieldDefinition) + ' ';
              } else {
                formattedValue += fieldValue.toString();
              }
            }
          }
        });
      return <NoAccess prefix={formattedValue} />;
    }
    if (this.props.orientation !== 'horizontal') {
      let description = '';
      let isFirstField = true;
      for (let i: number = 0; i < this.props.fieldDefinitions.length; i++) {
        const fieldDefinition: FieldDefinition = this.props.fieldDefinitions[i];
        let propertyName: string = fieldDefinition.name;
        let value: ?string | ?number = this.props.item[propertyName];
        if (value === undefined || value === null) {
          if (fieldDefinition.label) {
            propertyName = fieldDefinition.label;
            value = this.props.item[propertyName];
          }
        }
        if (value !== undefined && value !== null) {
          let formattedValue: string = formatFieldValue(value, fieldDefinition);
          if (formattedValue && formattedValue !== '') {
            if (!isFirstField && !description.trim().endsWith(':')) {
              description += ', ';
            }
            if (this.props.showLabels && this.props.fieldDefinitions[i].label) {
              description += this.props.fieldDefinitions[i].label + ': ';
            }
            description += formattedValue;
            isFirstField = false;
          }
        }
      }
      return <Text style={styles.textLeftNoWidth}>{description}</Text>;
    }
    return (
      <View>
        {' '}
        <Text style={styles.text}>
          {this.props.item[this.props.fieldDefinitions[0].label]}
        </Text>
        <Text style={styles.text}>
          {this.props.item[this.props.fieldDefinitions[0].label]}
        </Text>
      </View>
    );
  }
}

class EditableItem extends Component {
  props: {
    item: any,
    fieldDefinitions: FieldDefinition[],
    titleFields: string[],
    isSelected: boolean,
    orientation?: string,
    editable?: boolean,
    onUpdateItem: (propertyName: string, value: any) => void,
  };

  static defaultProps = {
    editable: true,
  };

  format(value: string[] | string): string {
    if (!value) {
      return '';
    }
    if (value instanceof Array) {
      const values: string[] = value;
      if (values.length === 0) {
        return '';
      }
      let formattedText: string = values[0];
      for (var i = 1; i < values.length; i++) {
        formattedText = formattedText + ', ' + values[i];
      }
      return formattedText;
    }
    return value;
  }

  renderTitle() {
    let title: string = '';
    this.props.titleFields &&
      this.props.titleFields.forEach((titleField: string) => {
        title = title + this.props.item[titleField] + ' ';
      });
    title = title.trim();
    if (title.length > 0) {
      return <Text style={styles.screenTitle}>{title}</Text>;
    }
  }

  render() {
    let isAllNormal: boolean = true;
    let style =
      this.props.orientation === 'horizontal' ? styles.flow : styles.form;
    if (this.props.isSelected) {
      style = [style, {backgroundColor: selectionColor}];
    }
    if (this.props.item?.noaccess) {
      return (
        <View style={style}>
          {this.renderTitle()}
          <NoAccess />
        </View>
      );
    }
    return (
      <View style={style}>
        {this.renderTitle()}
        {this.props.fieldDefinitions.map(
          (fieldDefinition: FieldDefinition, index: number) => {
            if (
              this.props.titleFields &&
              this.props.titleFields.includes(fieldDefinition.name)
            ) {
              return;
            }
            let description: string = this.format(
              this.props.item[fieldDefinition.name],
            );
            if (!description && fieldDefinition.normalValue) {
              isAllNormal = false;
            }
            if (!description) {
              return null;
            }
            isAllNormal = false;
            const propertyField = (
              <FormTextInput
                key={index}
                label={
                  fieldDefinition.label
                    ? fieldDefinition.label
                    : fieldDefinition.name
                }
                value={description}
                readonly={!this.props.editable}
                onChangeText={(text: string) =>
                  this.props.onUpdateItem(
                    fieldDefinition.name,
                    text.split(', '),
                  )
                }
              />
            );
            if (this.props.orientation === 'horizontal') {
              return propertyField;
            }
            return <FormRow key={index}>{propertyField}</FormRow>;
          },
        )}
        {isAllNormal && (
          <Text style={styles.textfield}>{strings.allNormal}</Text>
        )}
      </View>
    );
  }
}

export class ItemsCard extends Component {
  props: {
    exam: Exam,
    showTitle?: boolean,
  };
  static defaultProps = {
    showTitle: true,
  };

  renderItem(examItem: any, index: number) {
    if (this.props.exam.definition.fields === undefined) {
      return;
    }
    let fields = this.props.exam.definition.cardFields;
    if (fields === undefined || fields.length === 0) {
      fields = this.props.exam.definition.fields.map(
        (fieldDefinition: FieldDefinition) => fieldDefinition.name,
      );
    }

    let abnormalFields: string[] = fields.filter((field: string) => {
      let value: string | string[] = examItem[field];
      if (
        (this.props.exam.definition.cardFields === undefined ||
          this.props.exam.definition.cardFields.length === 0) &&
        (value === undefined || value === null)
      ) {
        const fieldDef: FieldDefinition =
          this.props.exam.definition.fields.find(
            (fieldDefinition: FieldDefinition) =>
              fieldDefinition.name === field,
          );
        if (fieldDef) {
          field = fieldDef.label;
          value = examItem[field];
        }
      }
      if (
        value === undefined ||
        value === null ||
        (value instanceof Array && value.length === 0)
      ) {
        return false;
      }
      let fieldDefinition: ?GroupDefinition | FieldDefinition =
        this.props.exam.definition.fields.find(
          (fieldDefinition: GroupDefinition | FieldDefinition) =>
            fieldDefinition.name === field,
        );
      if (fieldDefinition === undefined || fieldDefinition === null) {
        fieldDefinition = this.props.exam.definition.fields.find(
          (fieldDefinition: GroupDefinition | FieldDefinition) =>
            fieldDefinition.label === field,
        );
      }
      if (fieldDefinition === undefined || fieldDefinition === null) {
        return true;
      }

      return true;
    });

    let abnormalFieldOutput = '';
    return (
      <View
        style={
          this.props.exam.definition.editable
            ? styles.columnLayout
            : styles.topFlow
        }
        key={index}>
        {this.props.exam.definition.titleFields &&
          this.props.exam.definition.titleFields.map((titleField: string) => {
            return (
              <Text style={styles.boldText} key={titleField}>
                {examItem[titleField]}{' '}
              </Text>
            );
          })}
        {abnormalFields.map((field: string, subIndex: number) => {
          let value: string | string[] = examItem[field];
          if (this.props.exam.definition.fields === undefined) {
            return null;
          }
          if (
            (this.props.exam.definition.cardFields === undefined ||
              this.props.exam.definition.cardFields.length === 0) &&
            (value === undefined || value === null)
          ) {
            const fieldDef: FieldDefinition =
              this.props.exam.definition.fields.find(
                (fieldDefinition: FieldDefinition) =>
                  fieldDefinition.name === field,
              );
            if (fieldDef) {
              field = fieldDef.label;
              value = examItem[field];
            }
          }

          let fieldDefinition: ?GroupDefinition | FieldDefinition =
            this.props.exam.definition.fields.find(
              (fieldDefinition: GroupDefinition | FieldDefinition) =>
                fieldDefinition.name === field,
            );
          if (fieldDefinition === null || fieldDefinition === undefined) {
            fieldDefinition = this.props.exam.definition.fields.find(
              (fieldDefinition: GroupDefinition | FieldDefinition) =>
                fieldDefinition.label === field,
            );
          }

          if (fieldDefinition === null || fieldDefinition === undefined) {
            return null;
          }
          const label = this.props.exam.definition.editable
            ? formatLabel(fieldDefinition) + ': '
            : '';
          const valueOutput = `${
            !isEmpty(abnormalFieldOutput.trim()) && isEmpty(label) ? ', ' : ''
          }${formatFieldValue(value, fieldDefinition)}`;
          abnormalFieldOutput += valueOutput;
          return (
            <Text style={styles.textLeft} key={subIndex}>
              <Text style={fieldDefinition.highlightedLabel ? styles.labelTitle : ''}>
                {label}
              </Text>
              {valueOutput}
            </Text>
          );
        })}
      </View>
    );
  }

  render() {
    if (
      !this.props.exam[this.props.exam.definition.name] ||
      !this.props.exam[this.props.exam.definition.name].length ||
      Object.keys(this.props.exam[this.props.exam.definition.name][0])
        .length === 0 ||
      !this.props.exam.definition.fields
    ) {
      return (
        <View style={styles.columnLayout}>
          {this.props.showTitle && (
            <Label
              style={styles.cardTitle}
              value={
                this.props.exam.definition.label
                  ? this.props.exam.definition.label
                  : this.props.exam.definition.name
              }
              suffix=""
              fieldId={this.props.exam.definition.id}
            />
          )}
        </View>
      );
    }
    return (
      <View style={styles.columnLayout}>
        {this.props.showTitle && (
          <Label
            style={styles.cardTitle}
            value={
              this.props.exam.definition.label
                ? this.props.exam.definition.label
                : this.props.exam.definition.name
            }
            suffix=""
            fieldId={this.props.exam.definition.id}
          />
        )}
        {this.props.exam[this.props.exam.definition.name].map(
          (examItem: any, index: number) => {
            return this.renderItem(examItem, index);
          },
        )}
      </View>
    );
  }
}

export class ItemsList extends Component {
  props: {
    title?: string,
    items: any[],
    fieldDefinitions: FieldDefinition[],
    titleFields?: string[],
    selectedItem?: any,
    onAddItem?: () => void,
    onUpdateItem?: (propertyName: string, value: any) => void,
    onSelectItem?: (item: any) => void,
    onRemoveItem?: (item: any) => void,
    onAddFavorite?: (item: any) => void,
    onRemoveAllItems?: () => void,
    orientation?: string,
    itemView?: string,
    editable?: boolean,
    style?: any,
    showLabels?: boolean,
    testID: string,
  };
  static defaultProps = {
    editable: true,
  };

  allNormal(): void {
    this.props.fieldDefinitions?.forEach(
      (fieldDefinition: FieldDefinition, index: number) => {
        if (fieldDefinition.normalValue) {
          if (fieldDefinition.multiValue) {
            this.props.onUpdateItem(fieldDefinition.name, [
              fieldDefinition.normalValue,
            ]);
          } else {
            this.props.onUpdateItem(
              fieldDefinition.name,
              fieldDefinition.normalValue,
            );
          }
        }
      },
    );
  }

  othersNormal(): void {
    this.props.fieldDefinitions?.forEach(
      (fieldDefinition: FieldDefinition, index: number) => {
        const propertyName: string = fieldDefinition.name;
        if (
          (this.props.selectedItem[propertyName] === undefined ||
            this.props.selectedItem[propertyName].length === 0) &&
          fieldDefinition.normalValue
        ) {
          if (fieldDefinition.multiValue) {
            this.props.onUpdateItem(propertyName, [
              fieldDefinition.normalValue,
            ]);
          } else {
            this.props.onUpdateItem(propertyName, fieldDefinition.normalValue);
          }
        }
      },
    );
  }

  renderButtons() {
    const fontColor: string = '#1db3b3';
    if (!this.props.editable || this.props.onAddItem) {
      return null;
    }
    return (
      <View style={styles.buttonsRowLayout}>
        <View style={styles.buttonsRowStartLayout}>
          <Button
            title={strings.allNormal}
            color={fontColor}
            onPress={() => {
              this.allNormal();
            }}
            testID={this.props.testID + '.normal'}
          />
          <Button
            title={strings.othersNormal}
            color={fontColor}
            onPress={() => {
              this.othersNormal();
            }}
            testID={this.props.testID + '.allNormal'}
          />
        </View>
      </View>
    );
  }

  renderIcons() {
    if (!this.props.editable || this.props.onRemoveAllItems === undefined) {
      return null;
    }
    return (
      <View style={styles.groupIcons}>
        <TouchableOpacity
          onPress={this.props.onRemoveAllItems}
          testID={this.props.testID + '.garbageIcon'}>
          <Garbage style={styles.groupIcon} />
        </TouchableOpacity>
      </View>
    );
  }

  renderRow(itemView: Component, index: number): Component {
    return (
      <View key={index} style={{flexDirection: 'row'}}>
        {itemView}
      </View>
    );
  }

  renderList(): Component {
    const itemOrientation: string =
      this.props.orientation === 'vertical' ? 'horizontal' : 'vertical';
    const isEditable: boolean = this.props.editable === true;
    return this.props.items.map((item: ?Prescription | any, index: number) => {
      const isSelected: boolean =
        this.props.selectedItem === item && this.props.items.length > 1;
      const itemView = constructItemView(
        this.props.itemView,
        item,
        this.props.fieldDefinitions,
        isSelected,
        isEditable,
        this.props.onUpdateItem,
        itemOrientation,
        this.props.titleFields,
        this.props.showLabels,
      );
      if (!this.props.onSelectItem || isEditable !== true) {
        return this.renderRow(itemView, index);
      }
      return (
        <TouchableHighlight
          testID={`medication-item-${item?.Label}`}
          key={index}
          onPress={() => this.props.onSelectItem(item)}
          onLongPress={() =>
            item && this.props.onRemoveItem && this.props.onRemoveItem(item)
          }>
            {this.renderRow(itemView, index)}
        </TouchableHighlight>
      );
    });
  }

  render() {
    //const listStyle = this.props.orientation === 'horizontal' ? styles.listRow : styles.centeredColumnLayout;
    return (
      <View testID={`medication-list`} style={this.props.style ? this.props.style : styles.board}>
        {this.props.title && (
          <Text style={styles.cardTitle}>{this.props.title}</Text>
        )}
        <ScrollView>{this.renderList()}</ScrollView>
        {this.renderButtons()}
        {this.renderIcons()}
      </View>
    );
  }
}

export class ItemsEditor extends Component {
  props: {
    items: any[],
    newItem?: () => any,
    isEmpty?: (item: any) => boolean,
    isDirty?: boolean,
    fieldDefinitions: FieldDefinition[],
    titleFields?: string[],
    itemView?: string,
    orientation?: string,
    onUpdate?: () => void,
    favorites?: ExamPredefinedValue[],
    onAddFavorite?: (item: any) => void,
    onRemoveFavorite: (favorite: ExamPredefinedValue) => void,
    editable?: boolean,
    fieldId: string,
  };
  state: {
    selectedItem: any,
    isDirty: boolean,
  };
  static defaultProps = {
    editable: true,
  };

  constructor(props: any) {
    super(props);
    let items: T[] = this.props.items;
    if (this.props.editable) {
      if (items.length === 0 && this.props.newItem !== undefined) {
        items.push(this.props.newItem());
      }
      this.state = {
        selectedItem: items[0],
        isDirty: this.props.isDirty ? this.props.isDirty : false,
      };
    } else {
      this.state = {
        selectedItem: undefined,
        isDirty: this.props.isDirty ? this.props.isDirty : false,
      };
    }
  }

  componentDidUpdate(prevProps: any) {
    if (
      prevProps.isDirty === this.props.isDirty &&
      prevProps.items === this.props.items &&
      prevProps.editable === this.props.editable
    ) {
      return;
    }
    let items: T[] = this.props.items;
    if (this.props.editable) {
      if (items.length === 0 && this.props.newItem !== undefined) {
        items.push(this.props.newItem());
      }
      this.setState({
        selectedItem: items[0],
        isDirty: this.props.isDirty ? this.props.isDirty : false,
      });
    } else {
      this.setState({
        selectedItem: undefined,
        isDirty: this.props.isDirty === true ? true : false,
      });
    }
  }

  updateItem = (propertyName: string, value: any): void => {
    if (this.props.editable !== true) {
      return;
    }
    let item = this.state.selectedItem;
    const fieldIndex = this.props.fieldDefinitions.findIndex(
      (fieldDefinition: FieldDefinition) =>
        fieldDefinition.name === propertyName,
    );
    const fieldDefinition: ?FieldDefinition =
      this.props.fieldDefinitions[fieldIndex];
    if (fieldDefinition === undefined || fieldDefinition === null) {
      return;
    }
    //If field is a code replace value with code, taking selection prefix into account
    if (
      fieldDefinition.options &&
      fieldDefinition.options instanceof Array === false &&
      value !== undefined &&
      value !== null
    ) {
      const codeType: string = fieldDefinition.options;
      if (fieldDefinition.multiValue) {
        value = value.map(
          (description: string) =>
            selectionPrefix(description) +
            parseCode(codeType, stripSelectionPrefix(description)),
        );
      } else {
        value =
          selectionPrefix(value) +
          parseCode(codeType, stripSelectionPrefix(value));
      }
    }
    //Normal value handling
    if (
      fieldDefinition.normalValue !== undefined &&
      fieldDefinition.normalValue !== null
    ) {
      if (
        value &&
        value.length == 2 &&
        value[0].toLowerCase() === fieldDefinition.normalValue.toLowerCase()
      ) {
        value = value.splice(1);
      }
      if (
        value &&
        value.length > 1 &&
        value[value.length - 1].toLowerCase() ===
          fieldDefinition.normalValue.toLowerCase()
      ) {
        value = [fieldDefinition.normalValue];
      }
    }
    //Auto add or remove line
    if (this.props.newItem) {
      if (fieldIndex === 0) {
        if (value === undefined) {
          this.removeItem(item);
          return;
        } else if (
          item[fieldDefinition.name] !== undefined &&
          stripSelectionPrefix(value) !==
            stripSelectionPrefix(item[fieldDefinition.name])
        ) {
          item = this.addItem();
        }
      } else if (fieldIndex === 1 && fieldDefinition.newLine === true) {
        //I have no idea what this was for
        if (value === undefined) {
          this.removeItem(item);
          return;
        } else if (
          item[fieldDefinition.name] !== undefined &&
          stripSelectionPrefix(value) !==
            stripSelectionPrefix(item[fieldDefinition.name])
        ) {
          let newItem: any = this.props.newItem();
          newItem[this.props.fieldDefinitions[0].name] =
            item[this.props.fieldDefinitions[0].name];
          item = this.addItem(newItem);
        }
      }
    }
    //
    item[fieldDefinition.name] = value;
    this.setState({
      selectedItem: item,
    });
    this.props.onUpdate();
  };

  addItem(newItem: any): any {
    if (!this.props.newItem || !this.props.editable) {
      return;
    }
    if (newItem === undefined || newItem === null) {
      newItem = this.props.newItem();
    }
    this.props.items.push(newItem);
    this.setState({
      selectedItem: newItem,
      isDirty: true,
    });
    return newItem;
  }

  selectItem(item: any): void {
    if (!this.props.editable) {
      return;
    }
    this.setState({
      selectedItem: item,
    });
  }

  removeItem(item: any): void {
    if (!this.props.editable) {
      return;
    }
    let index: number = this.props.items.indexOf(item);
    if (index < 0) {
      return;
    }
    let items: any[] = this.props.items;
    items.splice(index, 1);
    if (items.length === 0) {
      items.push(this.props.newItem());
    }
    if (index >= items.length) {
      index = items.length - 1;
    }
    this.setState({
      selectedItem: items[index],
    });
    this.props.onUpdate();
  }

  removeAllItems = () => {
    if (!this.props.editable) {
      return;
    }
    this.props.items.splice(0, this.props.items.length);
    if (this.props.newItem !== undefined) {
      this.props.items.push(this.props.newItem());
      this.setState({selectedItem: this.props.items[0]});
    } else {
      this.props.items.push({});
      this.setState({selectedItem: this.props.items[0]});
    }
    this.props.onUpdate();
  };

  removeEmptyItems() {
    if (!this.props.isEmpty || !this.props.editable) {
      return;
    }
    let items: any[] = this.props.items;
    let i: number = 0;
    while (i < items.length) {
      if (this.props.isEmpty(items[i])) {
        items.splice(i, 1);
      } else {
        i++;
      }
    }
  }

  selectFavorite = (predefinedValue: ExamPredefinedValue) => {
    if (!predefinedValue || !predefinedValue.predefinedValue) {
      return;
    }
    const items: any[] = this.props.items;
    //Remove the first line if empty
    if (items.length === 1 && items[0] && Object.keys(items[0]).length === 0) {
      items.splice(0, 1);
    }
    let value = predefinedValue.predefinedValue;
    value = deepClone(value);
    if (value instanceof Array) {
      items.push(...value);
    } else {
      items.push(value);
    }
    if (items.length === 0 && this.props.newItem !== undefined) {
      items.push(this.props.newItem());
    }
    this.setState({selectedItem: items[items.length - 1]});
    this.props.onUpdate();
  };

  renderSelectionLists() {
    if (!this.props.fieldDefinitions) {
      return null;
    }
    return this.props.fieldDefinitions.map(
      (fieldDefinition: FieldDefinition, index: number) => {
        if (fieldDefinition.options && fieldDefinition.options.length > 2) {
          const propertyName: string = fieldDefinition.name;
          let selection = this.state.selectedItem
            ? this.state.selectedItem[propertyName]
            : undefined;

          let options: CodeDefinition[] | string = fieldDefinition.options;
          if (options instanceof Array === false) {
            //We got ourselves some codes
            const codeType: string = fieldDefinition.options;
            options = formatAllCodes(fieldDefinition.options);
            if (fieldDefinition.multiValue) {
              if (selection !== undefined && selection !== null) {
                selection = selection.map(
                  (code: string) =>
                    selectionPrefix(code) +
                    formatCode(codeType, stripSelectionPrefix(code)),
                );
              }
            } else {
              if (selection !== undefined && selection !== null) {
                selection =
                  selectionPrefix(selection) +
                  formatCode(codeType, stripSelectionPrefix(selection));
              }
            }
          }
          return (
            <SelectionList
              key={index}
              label={
                fieldDefinition.label === undefined
                  ? fieldDefinition.name
                  : fieldDefinition.label
              }
              items={options}
              multiValue={fieldDefinition.multiValue}
              required={fieldDefinition.required}
              freestyle={fieldDefinition.freestyle}
              simpleSelect={fieldDefinition.simpleSelect}
              selection={selection}
              onUpdateSelection={(value) =>
                this.updateItem(propertyName, value)
              }
              fieldId={this.props.fieldId + '.' + fieldDefinition.name}
            />
          );
        }
      },
    );
  }

  renderNonOptionFields() {
    if (!this.props.fieldDefinitions || !this.state.selectedItem) {
      return null;
    }
    let fields: FieldDefinition[] = this.props.fieldDefinitions.filter(
      (fieldDefinition: FieldDefinition) =>
        fieldDefinition.options === undefined ||
        fieldDefinition.options.length <= 2,
    );
    if (fields.length === 0) {
      return null;
    }
    let form = this.state.selectedItem;
    let groupDefinition: GroupDefinition = {
      name: 'nonSelectables',
      label: '',
      fields: fields,
      size: 'M',
    };
    const boardStyle = styles[`board${groupDefinition.size}`];
    const maxWidth = isWeb ? undefined : 520 * fontScale;

    return (
      <View>
        <GroupedForm
          form={form}
          definition={groupDefinition}
          onChangeField={this.updateItem}
          fieldId={this.props.fieldId}
          style={[boardStyle, { maxWidth }]}
        />
      </View>
    );
  }

  addFavorite = () => {
    this.props.onAddFavorite && this.props.onAddFavorite(this.props.items);
  };

  render() {
    return (
      <View style={styles.page}>
        <View style={styles.flowLeft} testID={'ItemsListLeft'}>
          <ItemsList
            items={this.props.items}
            fieldDefinitions={this.props.fieldDefinitions}
            titleFields={this.props.titleFields}
            onAddItem={this.props.newItem ? () => this.addItem() : undefined}
            onUpdateItem={this.updateItem}
            selectedItem={this.state.selectedItem}
            onSelectItem={(item: any) => this.selectItem(item)}
            onAddFavorite={this.props.onAddFavorite}
            onRemoveItem={(item: any) => this.removeItem(item)}
            onRemoveAllItems={this.removeAllItems}
            itemView={this.props.itemView}
            orientation={this.props.orientation}
            editable={this.props.editable}
            style={
              this.props.onAddFavorite && this.props.editable
                ? styles.boardStretch
                : styles.boardStretchL
            }
            testID={this.props.fieldId ?? ''}
          />
          {this.props.onAddFavorite && this.props.editable && (
            <Favorites
              favorites={this.props.favorites}
              onSelectFavorite={this.selectFavorite}
              onAddFavorite={this.addFavorite}
              onRemoveFavorite={this.props.onRemoveFavorite}
            />
          )}
        </View>
        {this.props.editable &&
          (isWeb ? (
            <View style={{flex: 100, flexDirection: 'row', flexWrap: 'wrap'}}>
              {this.renderSelectionLists()}
              {this.renderNonOptionFields()}
            </View>
          ) : (
            <ScrollView horizontal={true}>
              {this.renderSelectionLists()}
              {this.renderNonOptionFields()}
            </ScrollView>
          ))}
      </View>
    );
  }
}

export class SelectionListsScreen extends Component {
  props: {
    exam: Exam,
    onUpdateExam?: (exam: Exam) => void,
    editable?: boolean,
    favorites?: ExamPredefinedValue[],
    onAddFavorite?: (favorite: any) => void,
    onRemoveFavorite?: (favorite: ExamPredefinedValue) => void,
  };

  constructor(props: any) {
    super(props);
    //this.initialiseExam();
  }

  initialiseExam() {
    if (
      this.props.exam[this.props.exam.definition.name] === undefined ||
      JSON.stringify(this.props.exam[this.props.exam.definition.name]) == '{}'
    ) {
      this.props.exam[this.props.exam.definition.name] = [];
      if (!this.props.exam.definition.addable) {
        this.props.exam[this.props.exam.definition.name].push({});
      }
    }
  }

  newItem = () => {
    let newItem = {};
    return newItem;
  };

  isItemEmpty = (item: any) => {
    if (item === undefined || item === null || Object.keys(item).length === 0) {
      return true;
    }
    const examDefinition: ExamDefinition = this.props.exam.definition;
    if (examDefinition.essentialFields) {
      for (let i: number = 0; i < examDefinition.essentialFields.length; i++) {
        const field: string = examDefinition.essentialFields[i];
        const fieldValue = item[field];
        if (
          fieldValue === undefined ||
          fieldValue.length === 0 ||
          new String(fieldValue).trim() === ''
        ) {
          return true;
        }
      }
    } else {
      //TODO
    }
    return false;
  };

  render() {
    this.initialiseExam();
    return (
      <ItemsEditor
        items={this.props.exam[this.props.exam.definition.name]}
        newItem={this.props.exam.definition.addable ? this.newItem : undefined}
        isEmpty={this.isItemEmpty}
        fieldDefinitions={this.props.exam.definition.fields}
        titleFields={this.props.exam.definition.titleFields}
        itemView={
          this.props.exam.definition.editable ? 'EditableItem' : 'ItemSummary'
        }
        onUpdate={() =>
          this.props.onUpdateExam && this.props.onUpdateExam(this.props.exam)
        }
        editable={this.props.editable}
        isDirty={this.props.exam.errors !== undefined}
        favorites={
          this.props.exam.definition.starable ? this.props.favorites : undefined
        }
        onAddFavorite={
          this.props.exam.definition.starable
            ? this.props.onAddFavorite
            : undefined
        }
        onRemoveFavorite={
          this.props.exam.definition.starable
            ? this.props.onRemoveFavorite
            : undefined
        }
        fieldId={this.props.exam.definition.name}
      />
    );
  }
}

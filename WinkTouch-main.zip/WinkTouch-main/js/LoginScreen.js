/**
 * @flow
 */

'use strict';

import React, { Component } from 'react';
import {
  Button as RnButton,
  Image,
  Text,
  TextInput,
  View,
  TouchableOpacity,
  StatusBar,
  KeyboardAvoidingView,
  InteractionManager,
  Linking,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import codePush from 'react-native-code-push';
import DeviceInfo from 'react-native-device-info';
import type {
  Account,
  Store,
  User,
  Registration,
  Visit,
  AgentAssumption,
} from './Types';
import base64 from 'base-64';
import { styles, fontScale, isWeb } from './Styles';
import { Button, ListField, TilesField } from './Widgets';
import {
  strings,
  switchLanguage,
  getUserLanguage,
  getUserLanguageIcon,
} from './Strings';
import {
  getRestUrl,
  handleHttpError,
  getNextRequestNumber,
  getWinkEmrHostFromAccount,
  searchItems,
  isValidJson,
} from './Rest';
import {
  dbVersion,
  touchVersion,
  bundleVersion,
  deploymentVersion,
} from './Version';
import { isEmpty } from './Util';
import { cacheItemsById } from './DataCache';
import { AgentAsumptionScreen } from './Agent';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { WINK_APP_ACCOUNTS_URL } from '@env';
import axios, { HttpStatusCode } from 'axios';

const getAccountsUrl = () => isWeb ? process.env.WINK_APP_ACCOUNTS_URL : WINK_APP_ACCOUNTS_URL;

async function fetchAccounts(path: string) {
  if (!path) {
    return;
  }
  let privileged: boolean = false;
  let emrOnly: boolean = true;
  const url =
    getAccountsUrl() +
    '?dbVersion=' +
    encodeURIComponent(dbVersion) +
    '&path=' +
    encodeURIComponent(path) +
    '&biggerThen=true&privileged=' +
    privileged +
    '&emrOnly=' +
    emrOnly;

    console.log('Login URL =>', url);
  __DEV__ && console.log('Fetching accounts: ' + url);
  try {
    let httpResponse = await axios.get(url, {
      headers: {
        'Accept-language': getUserLanguage(),
      },
    });
    if(httpResponse?.error) {
      handleHttpError(httpResponse, httpResponse?.data);
    }
    let accounts: Account[] = httpResponse?.data;
    // Check For Valid Json
    if (!isValidJson(accounts)) {
      throw new Error('Invalid Json');
    }

    return accounts;
  } catch (error) {
    __DEV__ && console.log(error);
    alert(strings.fetchAccountsError);
    throw error;
  }
}

async function fetchStores(account: Account): Store[] {
  if (account === null || account === undefined) {
    return;
  }
  const searchCriteria = {accountsId: account.id};
  let restResponse = await searchItems('Store/list', searchCriteria);
  const stores: Store[] = restResponse.stores ? restResponse.stores : [];
  cacheItemsById(stores);
  return stores;
}
export class MfaScreen extends Component {
  props: {
    registration: Registration,
    account: Account,
    store: Store,
    userName: String,
    password: String,
    onLogin: (
      account: Account,
      user: User,
      store: Store,
      token: string,
    ) => void,
    onMfaReset: () => void,
    qrImageUrl: ?string,
    onScanQrCode: () => void,
  };

  state: {
    code: ?string,
  };
  constructor(props: any) {
    super(props);
    this.state = {
      code: undefined,
    };
  }

  async verify() {
    let mfaVerifyUrl = getRestUrl() + 'login/verifyCode';
    const userName = this.props.userName;
    const password: ?string = this.props.password;
    const code: ?string = this.state.code;
    if (isEmpty(userName) || isEmpty(password) || isEmpty(code)) {
      return;
    }

    const account: ?Account = this.props.account;
    let store: ?Store = this.props.store;
    if (!account || !store) {
      return;
    }
    let loginData = {
      accountsId: account.id.toString(),
      storeId: store.storeId.toString(),
      expiration: 24 * 365,
      deviceId: DeviceInfo.getUniqueId(),
    };
    const requestNr = getNextRequestNumber();
    __DEV__ &&
      console.log(
        'REQ ' + requestNr + ' POST ' + mfaVerifyUrl + ' login for ' + userName,
      );
    try {
      let httpResponse = await axios.post(mfaVerifyUrl, loginData, {
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json',
          'Accept-language': getUserLanguage(),
          Authorization: 'Basic ' + base64.encode(userName + ':' + password + ':' + code),
        },
      });
      console.log(
        'RES ' +
          requestNr +
          ' POST ' +
          mfaVerifyUrl +
          ' login OK for ' +
          userName +
          ':' +
          httpResponse.ok,
      );
      if(httpResponse?.error) {
        handleHttpError(httpResponse, httpResponse?.data);
      }
      
      let responseJson = httpResponse?.data;
      // Check For Valid Json
      if (!isValidJson(responseJson)) {
        throw new Error('Invalid Json');
      }

      let token: string;
      if (isWeb) {
        for (let entry of httpResponse?.headers) {
          if (entry[0] === 'token') {
            token = entry[1];
          }
        }
      } else {
        token = httpResponse.headers.token;
      }

      let user: User = responseJson.user;
      store = responseJson.store;
      this.props.onLogin(account, user, store, token);
    } catch (error) {
      alert(strings.loginFailed + ': ' + error);
    }
  }

  async scanCode() {
    let mfaScanUrl = getRestUrl() + 'login/scanCode';
    const userName = this.props.userName;
    const password: ?string = this.props.password;
    if (isEmpty(userName) || isEmpty(password)) {
      return;
    }

    const account: ?Account = this.props.account;
    let store: ?Store = this.props.store;
    if (!account || !store) {
      return;
    }
    let loginData = {
      accountsId: account.id.toString(),
      storeId: store.storeId.toString(),
      expiration: 24 * 365,
      deviceId: DeviceInfo.getUniqueId(),
    };
    const requestNr = getNextRequestNumber();
    __DEV__ &&
      console.log(
        'REQ ' + requestNr + ' POST ' + mfaScanUrl + ' login for ' + userName,
      );
    try {
      let httpResponse = await axios.put(mfaScanUrl, loginData, {
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json',
          'Accept-language': getUserLanguage(),
          Authorization: 'Basic ' + base64.encode(userName + ':' + password),
        }
      });
      console.log(
        'RES ' +
          requestNr +
          ' POST ' +
          mfaScanUrl +
          ' login OK for ' +
          userName +
          ':' +
          httpResponse.ok,
      );
      this.props.onScanQrCode();
    } catch (error) {
      alert(strings.loginFailed + ': ' + error);
    }
  }

  setCode = (code: ?string) => {
    this.setState({code});
  };

  render() {
    const style = isWeb
      ? [styles.centeredColumnLayout, {alignItems: 'center'}]
      : styles.centeredColumnLayout;

    return (
      <View style={styles.screeen}>
        <StatusBar hidden={true} />
        <View style={style}>
          <KeyboardAvoidingView behavior="position">
            <View style={style}>
              <Text style={styles.h1}>
                {this.props.qrImageUrl
                  ? strings.mfaCodeScanTitle
                  : strings.mfaCodeVerificationTitle}
              </Text>
              <View>
                <TouchableOpacity
                  onLongPress={this.props.onMfaReset}
                  testID="login.registrationEmail">
                  <Text style={styles.label}>
                    {this.props.registration.email}
                  </Text>
                </TouchableOpacity>
              </View>
              {!this.props.qrImageUrl && (
                <Image
                  source={require('./image/winklogo-big.png')}
                  style={{
                    width: 250 * fontScale,
                    height: 250 * fontScale,
                    margin: 20 * fontScale,
                  }}
                />
              )}
              <View style={styles.fieldContainer}>
                {this.props.qrImageUrl ? (
                  <Image
                    source={{
                      uri: `data:image/png;base64,${this.props.qrImageUrl}`,
                    }}
                    style={{
                      width: 360 * fontScale,
                      height: 360 * fontScale,
                      margin: 20 * fontScale,
                    }}
                  />
                ) : (
                  <TextInput
                    placeholder={strings.enterCode}
                    autoCapitalize="none"
                    autoCorrect={false}
                    returnKeyType="go"
                    secureTextEntry={true}
                    ref="focusField"
                    style={styles.field400}
                    value={this.state.code}
                    selectTextOnFocus={true}
                    testID="login.mfaCodeField"
                    onChangeText={this.setCode}
                    onSubmitEditing={() => this.verify()}
                  />
                )}
              </View>

              <View
                style={
                  isWeb
                    ? (styles.buttonsRowLayout, {flex: 1})
                    : styles.buttonsRowLayout
                }>
                {this.props.qrImageUrl ? (
                  <Button
                    title={strings.mfaCodeScanned}
                    onPress={() => this.scanCode()}
                  />
                ) : (
                  <Button
                    title={strings.verifyCode}
                    onPress={() => this.verify()}
                  />
                )}
              </View>
            </View>
          </KeyboardAvoidingView>
        </View>
        <TouchableOpacity style={styles.flag} onPress={this.switchLanguage}>
          <Text testID={'switchLanguage'} style={styles.flagFont}>{getUserLanguageIcon()}</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.version}
          testID={'app-version'}
          onLongPress={() =>
            !isWeb
              ? codePush.restartApp()
              : window.location.reload()
          }>
          <Text style={styles.versionFont}>
            Version {deploymentVersion}.{touchVersion}.{bundleVersion}.
            {dbVersion}
          </Text>
        </TouchableOpacity>
      </View>
    );
  }
}
export class LoginScreen extends Component {
  props: {
    registration: Registration,
    onReset: () => void,
    onLogin: (
      account: Account,
      user: User,
      store: Store,
      token: string,
    ) => void,
    onMfaRequired: () => void,
  };
  state: {
    accounts: Account[],
    account: ?string,
    store: ?string,
    userName: ?string,
    password: ?string,
    isTrial: boolean,
    isMfaRequired: ?boolean,
    qrImageUrl: ?string,
    agentAssumptionRequired: ?boolean,
    agent: ?AgentAssumption,
    isSecureTextEntry: boolean,
  };
  constructor(props: any) {
    super(props);
    this.state = {
      accounts: [],
      account: undefined,
      store: undefined,
      userName: undefined,
      password: __DEV__ ? '1234' : undefined, // NOSONAR
      isTrial: false,
      isMfaRequired: false,
      qrImageUrl: undefined,
      agentAssumptionRequired: false,
      agent: {},
      isSecureTextEntry: true,
    };
  }
  componentDidUpdate(prevProps: any, prevState: any) {
    if (prevProps.registration !== this.props.registration) {
      this.fetchAccountsStores(this.props.registration);
    }
    if (prevState.account !== this.state.account) {
      let currAccount = this.state.accounts.find(
        (account) => account.name === this.state.account,
      );
      if (currAccount) {
        let store =
          currAccount.stores?.length > 0
            ? this.formatStore(currAccount.stores[0])
            : undefined;
        if (store === undefined) {
          this.fetchStores(currAccount);
        } else {
          this.setStore(store);
        }
      } else if (!currAccount && !this.state.account) {
        this.setStore(undefined);
      }
    }
  }

  async fetchStores(account: Account) {
    const storeStr: string = this.state.store;
    const stores: Store[] = await fetchStores(account);
    let accounts: Account[] = [...this.state.accounts];
    let formattedStore: string;
    if (!isEmpty(storeStr)) {
      formattedStore =
        stores?.length > 0
          ? stores.find(
              (s: Store) =>
                this.formatStore(s).toLowerCase().trim() ===
                storeStr.toLowerCase().trim(),
            )
          : undefined;
    }
    if (isEmpty(formattedStore)) {
      formattedStore =
        stores?.length > 0 ? this.formatStore(stores[0]) : undefined;
    }
    account.stores = stores;
    const index = this.state.accounts.findIndex(
      (a: Account) => a.id === account.id,
    );
    if (index >= 0) {
      accounts[index] = account;
    }
    this.setState({accounts});
    this.setStore(formattedStore);
  }

  async componentDidMount() {
    await this.loadDefaultValues();
    this.fetchAccountsStores(this.props.registration);
  }

  reset = () => {
    AsyncStorage.removeItem('account');
    AsyncStorage.removeItem('store');
    AsyncStorage.removeItem('userName');
    this.props.onReset();
  };

  async fetchAccountsStores(registration: Registration) {
    if (!registration) {
      return;
    }
    let accounts: Account[] = await fetchAccounts(this.props.registration.path);
    if (!accounts) {
      accounts = [];
    }
    if (accounts !== this.state.accounts) {
      if (accounts.length === 0) {
        alert(strings.noAccountsWarning);
      }
      const isTrial = registration.email === 'DemoCustomer@downloadwink.com';
      if (!isTrial && accounts.length > 1) {
        accounts = accounts.filter(
          (account: Account) => account.isDemo !== true,
        );
      }
      let account = this.state.account;
      if (account === undefined && accounts.length > 0) {
        account = this.formatAccount(accounts[0]);

        if (accounts[0].stores && accounts[0].stores.length > 0) {
          let store = this.formatStore(accounts[0].stores[0]);
          this.setStore(store);
        } else {
          this.fetchStores(accounts[0]);
        }

        if (isTrial) {
          this.setState(
            {accounts, userName: 'Henry', password: 'Lomb', isTrial}, // NOSONAR
            this.setAccount(account),
          );
        } else {
          this.setState({accounts, isTrial}, this.setAccount(account));
        }
      } else {
        if (isTrial) {
          this.setState(
            {accounts, userName: 'Henry', password: 'Lomb', isTrial},  // NOSONAR
          );
        } else {
          this.setState({accounts, isTrial});
        }

        let currAccount = accounts.find((a: Account) => a.name === account);
        if (currAccount && (currAccount?.stores === null || currAccount?.stores === undefined)) {
          this.fetchStores(currAccount);
        }
      }
    }
  }

  async loadDefaultValues() {
    let account: ?string = await AsyncStorage.getItem('account');
    if (account == null) {
      account = undefined;
    }
    let store: ?string = await AsyncStorage.getItem('store');
    if (store === null) {
      store = undefined;
    }
    let userName: ?string = await AsyncStorage.getItem('userName');
    if (userName === null) {
      userName = undefined;
    }
    this.setState({account, store, userName});
  }

  getAccount(): ?Account {
    const selectedAccount: ?string = this.state.account;
    const account: ?Account = this.state.accounts.find(
      (account: Account) => this.formatAccount(account) === selectedAccount,
    );
    return account;
  }

  setAccount = (account: ?string) => {
    if (
      account === undefined ||
      account === null ||
      account.trim().length === 0
    ) {
      AsyncStorage.removeItem('account');
    } else {
      AsyncStorage.setItem('account', account);
    }
    this.setState({account});
  };

  formatAccount(account: Account) {
    return account.name;
  }

  setStore = (store: ?string) => {
    if (store === undefined || store === null || store.trim().length === 0) {
      AsyncStorage.removeItem('store');
    } else {
      AsyncStorage.setItem('store', store);
    }
    this.setState({store});
  };

  formatStore(store: Store) {
    return store.name + ' ' + store.city;
  }

  getStore(): ?Store {
    const selectedStore: ?string = this.state.store;
    let account: ?Account = this.getAccount();
    if (!account) {
      return undefined;
    }
    const store: ?Store = account.stores.find(
      (store: Store) => this.formatStore(store) === selectedStore,
    );
    return store;
  }

  setUserName = (userName: ?string) => {
    if (
      userName === undefined ||
      userName === null ||
      userName.trim().length === 0
    ) {
      AsyncStorage.removeItem('userName');
    } else {
      AsyncStorage.setItem('userName', userName);
    }
    this.setState({userName});
  };

  setPassword = (password: ?string) => {
    this.setState({password});
  };

  focusPasswordField = () => {
    this.refs.focusField.focus();
  };

  isOmsUser(): boolean {
    const username: string = this.state.userName;
    if (isEmpty(username)) {
      return false;
    }
    const endPart: string = username.substring(username.indexOf('@'));
    return endPart.toLowerCase().trim() === '@downloadwink.com';
  }

  async processLogin() {
    if (this.isOmsUser()) {
      this.setState({agentAssumptionRequired: true});
    } else {
      this.login();
    }
  }
  async login() {
    let loginPath: string = 'login/doctors';

    let userName = this.state.userName;
    if (
      userName === undefined ||
      userName === null ||
      userName.trim().length === 0
    ) {
      return;
    }
    let password: ?string = this.state.password;
    if (password === null || password === undefined) {
      password = '';
    }
    const account: ?Account = this.getAccount();
    let store: ?Store = this.getStore();
    if (!account || !store) {
      return;
    }
    let loginData = {
      accountsId: account.id.toString(),
      storeId: !isEmpty(store.id)
        ? store.id.toString()
        : store.storeId.toString(),
      expiration: 24 * 365,
      deviceId: DeviceInfo.getUniqueId(),
    };
    if (this.isOmsUser()) {
      loginPath = 'login/oms';
      loginData = {
        accountsId: account.id.toString(),
        storeId: !isEmpty(store.id)
          ? store.id.toString()
          : store.storeId.toString(),
        expiration: 24 * 365,
        deviceId: DeviceInfo.getUniqueId(),
        zendesk: this.state.agent.zendeskRef,
        reason: this.state.agent.reason,
      };
    }
    let doctorLoginUrl = getRestUrl() + loginPath;
    const requestNr = getNextRequestNumber();
    __DEV__ &&
      console.log(
        'REQ ' +
          requestNr +
          ' POST ' +
          doctorLoginUrl +
          ' login for ' +
          userName,
      );
    try {
      let httpResponse;
        httpResponse = await axios.post(doctorLoginUrl, loginData, {
          headers: {
            'Content-Type': 'application/json',
            Accept: 'application/json',
            'Accept-language': getUserLanguage(),
            Authorization: 'Basic ' + base64.encode(userName + ':' + password),
          }
        });

      console.log(
        'RES ' +
          requestNr +
          ' POST ' +
          doctorLoginUrl +
          ' login OK for ' +
          userName +
          ':' +
          httpResponse.status,
      );

      if(httpResponse?.error) {
        handleHttpError(httpResponse, httpResponse?.data);
      }

      let responseJson = httpResponse?.data;
      // Check For Valid Json
      if (!isValidJson(responseJson)) {
        throw new Error('Invalid Json');
      }

      if (responseJson?.mfa === true) {
        if (responseJson.secretImageUri) {
          this.setQRImageUrl(responseJson.secretImageUri);
        }
        this.setMfaRequired(true);
      } else {
        let token: string;
        if (isWeb) {
          for (let entry of httpResponse?.headers) {
            if (entry[0] === 'token') {
              token = entry[1];
            }
          }
        } else {
          token = httpResponse?.headers?.token;
        }

        let user: User = responseJson.user;
        store = responseJson.store;
        this.props.onLogin(account, user, store, token);
      }
    } catch (error) {
      alert(strings.loginFailed + ': ' + (strings[error] || error));
    }
    this.setState({agentAssumptionRequired: false});
  }

  setQRImageUrl = (qrImageUrl: string) => {
    this.setState({
      qrImageUrl: qrImageUrl,
    });
  };
  setMfaRequired = (mfa: boolean) => {
    this.setState({
      isMfaRequired: mfa,
    });
  };

  setAgentAssumption(agent: AgentAssumption) {
    this.setState({agent}, () => this.login());
  }

  toggleSecuredTextState(isSecureTextEntry: boolean) {
    this.setState({isSecureTextEntry: !isSecureTextEntry});
    this.focusPasswordField();
  }

  switchLanguage = () => {
    switchLanguage();
    this.forceUpdate();
  };

  renderMfaScreen() {
    return (
      <MfaScreen
        registration={this.props.registration}
        account={this.getAccount()}
        store={this.getStore()}
        userName={this.state.userName}
        password={this.state.password}
        onLogin={(account: Account, user: User, store: Store, token: string) =>
          this.props.onLogin(account, user, store, token)
        }
        onMfaReset={() => this.setMfaRequired(false)}
        onScanQrCode={() => this.setQRImageUrl(undefined)}
        qrImageUrl={this.state.qrImageUrl}
      />
    );
  }
  render() {
    if (this.state.isMfaRequired) {
      return this.renderMfaScreen();
    }
    if (this.isOmsUser() && this.state.agentAssumptionRequired) {
      return (
        <AgentAsumptionScreen
          onConfirmLogin={(agent: AgentAssumption) =>
            this.setAgentAssumption(agent)
          }
        />
      );
    }
    const style = isWeb
      ? [styles.centeredColumnLayout, {alignItems: 'center'}]
      : styles.centeredColumnLayout;

    const accountNames: string[] = this.state.accounts.map((account: Account) =>
      this.formatAccount(account),
    );
    const account: ?Account = this.getAccount();
    const storeNames: string[] =
      account && account.stores
        ? account.stores.map((store: Store) => this.formatStore(store))
        : [];
    return (
      <View style={styles.screeen}>
        <StatusBar hidden={true} />
        <View style={style}>
          <KeyboardAvoidingView behavior="position">
            <View style={style}>
              {!this.state.isTrial && (
                <Text style={styles.h1}>{strings.loginscreenTitle}</Text>
              )}
              {this.state.isTrial && (
                <View>
                  <TouchableOpacity onPress={this.reset}>
                    <Text style={styles.h1}>{strings.loginscreenTitle}</Text>
                  </TouchableOpacity>
                  <Text style={{fontSize: 25 * fontScale, color: 'red'}}>
                    {strings.trialWarning}
                  </Text>
                  <RnButton
                    title={strings.winkLink}
                    onPress={() => {
                      Linking.openURL('https://www.downloadwink.com');
                    }}
                  />
                </View>
              )}
              {!this.state.isTrial && (
                <View>
                  <TouchableOpacity
                    onLongPress={this.reset}
                    testID="login.registrationEmail">
                    <Text style={styles.label}>
                      {this.props.registration.email}
                    </Text>
                  </TouchableOpacity>
                </View>
              )}
              <Image
                source={require('./image/winklogo-big.png')}
                style={{
                  width: 250 * fontScale,
                  height: 250 * fontScale,
                  margin: 20 * fontScale,
                }}
              />
              <View>
                <ListField
                  label={strings.account}
                  freestyle={true}
                  value={this.state.account}
                  style={styles.field400}
                  containerStyle={styles.fieldContainer}
                  options={accountNames}
                  onChangeValue={this.setAccount}
                  popupStyle={styles.alignPopup}
                  simpleSelect={true}
                  renderOptionsOnly={true}
                  isValueRequired={true}
                  testID="login.account"
                />
              </View>
              <View>
                <ListField
                  label={strings.store}
                  freestyle={true}
                  value={this.state.store}
                  style={styles.field400}
                  containerStyle={styles.fieldContainer}
                  options={storeNames}
                  onChangeValue={this.setStore}
                  simpleSelect={true}
                  isValueRequired={true}
                  renderOptionsOnly={true}
                  popupStyle={styles.alignPopup}
                  testID="login.store"
                />
              </View>
              {!this.state.isTrial && (
                <View style={styles.fieldContainer}>
                  <TextInput
                    placeholder={strings.userName}
                    autoCapitalize="none"
                    autoCorrect={false}
                    returnKeyType="next"
                    style={styles.field400}
                    value={this.state.userName}
                    onChangeText={this.setUserName}
                    onSubmitEditing={this.focusPasswordField}
                    testID="login.userNameField"
                  />
                </View>
              )}
              {!this.state.isTrial && (
                <View style={styles.fieldContainer}>
                  <TextInput
                    placeholder={strings.password}
                    autoCapitalize="none"
                    autoCorrect={false}
                    returnKeyType="go"
                    secureTextEntry={this.state.isSecureTextEntry}
                    ref="focusField"
                    style={styles.field400}
                    value={this.state.password}
                    selectTextOnFocus={true}
                    testID="login.passwordField"
                    onChangeText={this.setPassword}
                    onSubmitEditing={() => this.processLogin()}
                  />
                  <TouchableOpacity
                    style={{position: 'absolute', right: 0, alignSelf: 'center'}}
                    onPress={() => this.toggleSecuredTextState(this.state.isSecureTextEntry)}
                  >
                    <View>
                      {this.state.isSecureTextEntry
                      ?
                      <Icon testID={'showPasswordIcon'} name="eye" style={[styles.screenIcon, styles.paddingLeftRight10]} color="gray" />
                      :
                      <Icon testID={'hidePasswordIcon'} name="eye-off" style={[styles.screenIcon, styles.paddingLeftRight10]} color="gray" />}
                    </View>
                  </TouchableOpacity>
                </View>
              )}
              <View
                style={
                  isWeb
                    ? (styles.buttonsRowLayout, {flex: 1})
                    : styles.buttonsRowLayout
                }>
                <Button
                  title={strings.submitLogin}
                  disabled={account === undefined}
                  onPress={() => this.processLogin()}
                />
              </View>
            </View>
          </KeyboardAvoidingView>
        </View>
        <TouchableOpacity testID={'switchLanguage'} style={styles.flag} onPress={this.switchLanguage}>
          <Text style={styles.flagFont}>{getUserLanguageIcon()}</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.version}
          onLongPress={() =>
            !isWeb
              ? codePush.restartApp()
              : window.location.reload()
          }>
          <Text style={styles.versionFont}>
            Version {deploymentVersion}.{touchVersion}.{bundleVersion}.
            {dbVersion}
          </Text>
        </TouchableOpacity>
      </View>
    );
  }
}

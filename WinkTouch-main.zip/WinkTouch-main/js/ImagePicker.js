/**
 * @flow
 */
'use strict';

import React, {Component} from 'react';
import {Text} from 'react-native';

export class ImagePicker extends Component {
  render() {
    return <Text>Image android picker</Text>;
  }
}
